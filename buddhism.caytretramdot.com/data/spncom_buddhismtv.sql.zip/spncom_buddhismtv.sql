-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jul 06, 2014 at 07:59 PM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `spncom_buddhismtv`
--

-- --------------------------------------------------------

--
-- Table structure for table `buddhismtv_district`
--

CREATE TABLE IF NOT EXISTS `buddhismtv_district` (
  `id` bigint(11) NOT NULL,
  `id_province` bigint(11) NOT NULL,
  `name` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `latitude` float NOT NULL,
  `longitude` float NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_province` (`id_province`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `buddhismtv_district`
--

INSERT INTO `buddhismtv_district` (`id`, `id_province`, `name`, `latitude`, `longitude`) VALUES
(1, 1, 'Quận 1', 0, 0),
(2, 1, 'Quận 2', 0, 0),
(3, 1, 'Quận 3', 0, 0),
(4, 1, 'Quận 4', 0, 0),
(5, 1, 'Quận 5', 0, 0),
(6, 1, 'Quận 6', 0, 0),
(7, 1, 'Quận 7', 0, 0),
(8, 1, 'Quận 8', 0, 0),
(9, 1, 'Quận 9', 0, 0),
(10, 1, 'Quận 10', 0, 0),
(11, 1, 'Quận 11', 0, 0),
(12, 1, 'Quận 12', 0, 0),
(13, 1, 'Thủ Đức', 0, 0),
(14, 1, 'Tân Phú', 0, 0),
(15, 1, 'Tân Bình', 0, 0),
(16, 1, 'Phú Nhuận', 0, 0),
(17, 1, 'Gò Vấp', 0, 0),
(18, 1, 'Bình Thạnh', 0, 0),
(19, 1, 'Bình Tân', 0, 0),
(20, 1, 'Bình Chánh', 0, 0),
(21, 1, 'Cần Giờ', 0, 0),
(22, 1, 'Củ Chi', 0, 0),
(23, 1, 'Hóc Môn', 0, 0),
(24, 1, 'Nhà Bè', 0, 0),
(25, 58, 'Thành phố Vĩnh Long', 0, 0),
(26, 58, 'Thị xã Bình Minh', 0, 0),
(27, 58, 'Huyện Bình Tân', 0, 0),
(28, 58, 'Huyện Long Hồ', 0, 0),
(29, 58, 'Huyện Mang Thít', 0, 0),
(30, 58, 'Huyện Tam Bình', 0, 0),
(31, 58, 'Huyện Trà Ôn', 0, 0),
(32, 58, 'Huyện Vũng Liêm', 0, 0),
(33, 20, 'Thành phố Biên Hòa', 0, 0),
(34, 20, 'Thị xã Long Khánh', 0, 0),
(35, 20, 'Huyện Long Thành', 0, 0),
(36, 20, 'Huyện Nhơn Trạch', 0, 0),
(37, 20, 'Huyện Trảng Bom', 0, 0),
(38, 20, 'Huyện Thống Nhất', 0, 0),
(39, 20, 'Huyện Vĩnh Cửu', 0, 0),
(40, 20, 'Huyện Cẩm Mỹ', 0, 0),
(41, 20, 'Huyện Xuân Lộc', 0, 0),
(42, 20, 'Huyện Tân Phú', 0, 0),
(43, 20, 'Huyện Định Quán', 0, 0),
(44, 2, 'Quận Ba Đình', 0, 0),
(45, 2, 'Quận Hoàn Kiếm', 0, 0),
(46, 2, 'Quận Tây Hồ', 0, 0),
(47, 2, 'Quận Long Biên', 0, 0),
(48, 2, 'Quận Cầu Giấy', 0, 0),
(49, 2, 'Quận Đống Đa', 0, 0),
(50, 2, 'Quận Hai Bà Trưng', 0, 0),
(51, 2, 'Quận Hoàng Mai', 0, 0),
(52, 2, 'Quận Thanh Xuân', 0, 0),
(53, 2, 'Quận Hà Đông', 0, 0),
(54, 2, 'Quận Bắc Từ Liêm', 0, 0),
(55, 2, 'Quận Nam Từ Liêm', 0, 0),
(56, 2, 'Huyện Ba Vì', 0, 0),
(57, 2, 'Huyện Chương Mỹ', 0, 0),
(58, 2, 'Huyện Đan Phượng', 0, 0),
(59, 2, 'Huyện Đông Anh', 0, 0),
(60, 2, 'Huyện Gia Lâm', 0, 0),
(61, 2, 'Huyện Hoài Đức', 0, 0),
(62, 2, 'Huyện Mê Linh', 0, 0),
(63, 2, 'Huyện Mỹ Đức', 0, 0),
(64, 2, 'Huyện Phú Xuyên', 0, 0),
(65, 2, 'Huyện Phúc Thọ', 0, 0),
(66, 2, 'Huyện Quốc Oai', 0, 0),
(67, 2, 'Huyện Sóc Sơn', 0, 0),
(68, 2, 'Huyện Thạch Thất', 0, 0),
(69, 2, 'Huyện Thanh Oai', 0, 0),
(70, 2, 'Huyện Thanh Trì', 0, 0),
(71, 2, 'Huyện Thường Tín', 0, 0),
(72, 2, 'Huyện Ứng Hòa', 0, 0),
(73, 3, 'Quận Ninh Kiều', 0, 0),
(74, 3, 'Quận Bình Thủy', 0, 0),
(75, 3, 'Quận Cái Răng', 0, 0),
(76, 3, 'Quận Ô Môn', 0, 0),
(77, 3, 'Quận Thốt Nốt', 0, 0),
(78, 3, 'Huyện Phong Điền', 0, 0),
(79, 3, 'Huyện Cờ Đỏ', 0, 0),
(80, 3, 'Huyện Thới Lai', 0, 0),
(81, 3, 'Huyện Vĩnh Thạnh', 0, 0),
(82, 4, 'Thành phố Long Xuyên', 0, 0),
(83, 4, 'Thành phố Châu Đốc', 0, 0),
(84, 4, 'Thị xã Tân Châu', 0, 0),
(85, 4, 'Huyện An Phú', 0, 0),
(86, 4, 'Huyện Châu Phú', 0, 0),
(87, 4, 'Huyện Châu Thành', 0, 0),
(88, 4, 'Huyện Chợ Mới', 0, 0),
(89, 4, 'Huyện Phú Tân', 0, 0),
(90, 4, 'Huyện Thoại Sơn', 0, 0),
(91, 4, 'Huyện Tịnh Biên', 0, 0),
(92, 4, 'Huyện Tri Tôn', 0, 0),
(93, 21, 'Thành phố Cao Lãnh', 0, 0),
(94, 21, 'Thành phố Sa Đéc', 0, 0),
(95, 21, 'Thị xã Hồng Ngự', 0, 0),
(96, 21, 'Huyện Cao Lãnh', 0, 0),
(97, 21, 'Huyện Châu Thành', 0, 0),
(98, 21, 'Huyện Hồng Ngự', 0, 0),
(99, 21, 'Huyện Lai Vung', 0, 0),
(100, 21, 'Huyện Lấp Vò', 0, 0),
(101, 21, 'Huyện Tam Nông', 0, 0),
(102, 21, 'Huyện Tân Hồng', 0, 0),
(103, 21, 'Huyện Thanh Bình', 0, 0),
(104, 21, 'Huyện Tháp Mười', 0, 0),
(105, 48, 'Thành phố Sóc Trăng', 0, 0),
(106, 48, 'Thị xã Vĩnh Châu', 0, 0),
(107, 48, 'Thị xã Ngã Năm', 0, 0),
(108, 48, 'Huyện Long Phú', 0, 0),
(109, 48, 'Huyện Kế Sách', 0, 0),
(110, 48, 'Huyện Mỹ Tú', 0, 0),
(111, 48, 'Huyện Mỹ Xuyên', 0, 0),
(112, 48, 'Huyện Trần Đề', 0, 0),
(113, 48, 'Huyện Thạnh Trị', 0, 0),
(114, 48, 'Huyện Châu Thành', 0, 0),
(115, 48, 'Huyện Cù Lao Dung', 0, 0),
(116, 8, 'Thành phố Bạc Liêu', 0, 0),
(117, 8, 'Huyện Hồng Dân', 0, 0),
(118, 8, 'Huyện Hòa Bình', 0, 0),
(119, 8, 'Huyện Giá Rai', 0, 0),
(120, 8, 'Huyện Phước Long', 0, 0),
(121, 8, 'Huyện Vĩnh Lợi', 0, 0),
(122, 8, 'Huyện Đông Hải', 0, 0),
(123, 15, 'Thành phố Cà Mau', 0, 0),
(124, 15, 'Huyện Đầm Dơi', 0, 0),
(125, 15, 'Huyện Ngọc Hiển', 0, 0),
(126, 15, 'Huyện Cái Nước', 0, 0),
(127, 15, 'Huyện Trần Văn Thời', 0, 0),
(128, 15, 'Huyện U Minh', 0, 0),
(129, 15, 'Huyện Thới Bình', 0, 0),
(130, 15, 'Huyện Năm Căn', 0, 0),
(131, 15, 'Huyện Phú Tân', 0, 0),
(132, 31, 'Thành phố Rạch Giá', 0, 0),
(133, 31, 'Thị xã Hà Tiên', 0, 0),
(134, 31, 'Huyện An Biên', 0, 0),
(135, 31, 'Huyện An Minh', 0, 0),
(136, 31, 'Huyện Châu Thành', 0, 0),
(137, 31, 'Huyện Giồng Riềng', 0, 0),
(138, 31, 'Huyện Giang Thành', 0, 0),
(139, 31, 'Huyện Gò Quao', 0, 0),
(140, 31, 'Huyện Hòn Đất', 0, 0),
(141, 31, 'Huyện U Minh Thượng', 0, 0),
(142, 31, 'Huyện Kiên Lương', 0, 0),
(143, 31, 'Huyện Tân Hiệp', 0, 0),
(144, 31, 'Huyện Vĩnh Thuận', 0, 0),
(145, 31, 'Huyện Kiên Hải', 0, 0),
(146, 31, 'Huyện Phú Quốc', 0, 0),
(147, 56, 'Thành phố Trà Vinh', 0, 0),
(148, 56, 'Huyện Càng Long', 0, 0),
(149, 56, 'Huyện Cầu Kè', 0, 0),
(150, 56, 'Huyện Tiểu Cần', 0, 0),
(151, 56, 'Huyện Châu Thành', 0, 0),
(152, 56, 'Huyện Cầu Ngang', 0, 0),
(153, 56, 'Huyện Trà Cú', 0, 0),
(154, 56, 'Huyện Duyên Hải', 0, 0),
(155, 10, 'Thành phố Bến Tre', 0, 0),
(156, 10, 'Huyện Ba Tri', 0, 0),
(157, 10, 'Huyện Bình Đại', 0, 0),
(158, 10, 'Huyện Châu Thành', 0, 0),
(159, 10, 'Huyện Chợ Lách', 0, 0),
(160, 10, 'Huyện Giồng Trôm', 0, 0),
(161, 10, 'Huyện Mỏ Cày Bắc', 0, 0),
(162, 10, 'Huyện Mỏ Cày Nam', 0, 0),
(163, 10, 'Huyện Thạnh Phú', 0, 0),
(164, 55, 'Thành phố Mỹ Tho', 0, 0),
(165, 55, 'Thị xã Gò Công', 0, 0),
(166, 55, 'Thị xã Cai Lậy', 0, 0),
(167, 55, 'Huyện Cái Bè', 0, 0),
(168, 55, 'Huyện Gò Công Đông', 0, 0),
(169, 55, 'Huyện Gò Công Tây', 0, 0),
(170, 55, 'Huyện Chợ Gạo', 0, 0),
(171, 55, 'Huyện Châu Thành', 0, 0),
(172, 55, 'Huyện Tân Phước', 0, 0),
(173, 55, 'Huyện Cai Lậy', 0, 0),
(174, 55, 'Huyện Tân Phú Đông', 0, 0),
(175, 37, 'Thành phố Tân An', 0, 0),
(176, 37, 'Thị xã Kiến Tường', 0, 0),
(177, 37, 'Huyện Bến Lức', 0, 0),
(178, 37, 'Huyện Cần Đước', 0, 0),
(179, 37, 'Huyện Cần Giuộc', 0, 0),
(180, 37, 'Huyện Châu Thành', 0, 0),
(181, 37, 'Huyện Đức Huệ', 0, 0),
(182, 37, 'Huyện Mộc Hóa', 0, 0),
(183, 37, 'Huyện Tân Hưng', 0, 0),
(184, 37, 'Huyện Tân Thạnh', 0, 0),
(185, 37, 'Huyện Tân Trụ', 0, 0),
(186, 37, 'Huyện Thạnh Hóa', 0, 0),
(187, 37, 'Huyện Thủ Thừa', 0, 0),
(188, 37, 'Huyện Vĩnh Hưng', 0, 0),
(189, 37, 'Huyện Đức Hòa', 0, 0),
(190, 12, 'Thành phố Thủ Dầu Một', 0, 0),
(191, 12, 'Thị xã Thuận An', 0, 0),
(192, 12, 'Thị xã Dĩ An', 0, 0),
(193, 12, 'Thị xã Tân Uyên', 0, 0),
(194, 12, 'Thị xã Bến Cát', 0, 0),
(195, 12, 'Huyện Dầu Tiếng', 0, 0),
(196, 12, 'Huyện Phú Giáo', 0, 0),
(197, 12, 'Huyện Bắc Tân Uyên', 0, 0),
(198, 12, 'Huyện Bàu Bàng', 0, 0),
(199, 5, 'Thành phố Vũng Tàu', 0, 0),
(200, 5, 'Thành phố Bà Rịa', 0, 0),
(201, 5, 'Huyện Long Điền', 0, 0),
(202, 5, 'Huyện Đất Đỏ', 0, 0),
(203, 5, 'Huyện Châu Đức', 0, 0),
(204, 5, 'Huyện Tân Thành', 0, 0),
(205, 5, 'Huyện Côn Đảo', 0, 0),
(206, 5, 'Huyện Xuyên Mộc', 0, 0),
(207, 61, 'Thành phố Tuy Hòa', 0, 0),
(208, 61, 'Thị xã Sông Cầu', 0, 0),
(209, 61, 'Đông Hòa', 0, 0),
(210, 61, 'Đồng Xuân', 0, 0),
(211, 61, 'Phú Hòa', 0, 0),
(212, 61, 'Sơn Hòa', 0, 0),
(213, 61, 'Sông Hinh', 0, 0),
(214, 61, 'Tuy An', 0, 0),
(215, 61, 'Tây Hòa', 0, 0),
(216, 30, 'Thành phố Nha Trang', 0, 0),
(217, 30, 'Thành phố Cam Ranh', 0, 0),
(218, 30, 'Thị xã Ninh Hòa', 0, 0),
(219, 30, 'Huyện Vạn Ninh', 0, 0),
(220, 30, 'Huyện Diên Khánh', 0, 0),
(221, 30, 'Huyện Khánh Vĩnh', 0, 0),
(222, 30, 'Huyện Khánh Sơn', 0, 0),
(223, 30, 'Huyện Cam Lâm', 0, 0),
(224, 30, 'Huyện đảo Trường Sa', 0, 0),
(225, 34, 'Thành phố Đà Lạt', 0, 0),
(226, 34, 'Thành phố Bảo Lộc', 0, 0),
(227, 34, 'Huyện Bảo Lâm', 0, 0),
(228, 34, 'Huyện Cát Tiên', 0, 0),
(229, 34, 'Huyện Di Linh', 0, 0),
(230, 34, 'Huyện Đam Rông', 0, 0),
(231, 34, 'Huyện Đạ Huoai', 0, 0),
(232, 34, 'Huyện Đạ Tẻh', 0, 0),
(233, 34, 'Huyện Đơn Dương', 0, 0),
(234, 34, 'Huyện Lạc Dương', 0, 0),
(235, 34, 'Huyện Lâm Hà', 0, 0),
(236, 34, 'Huyện Đức Trọng', 0, 0),
(237, 27, 'Thành phố Vị Thanh', 0, 0),
(238, 27, 'Thị xã Ngã Bảy', 0, 0),
(239, 27, 'Huyện Châu Thành', 0, 0),
(240, 27, 'Huyện Châu Thành A', 0, 0),
(241, 27, 'Huyện Long Mỹ', 0, 0),
(242, 27, 'Huyện Phụng Hiệp', 0, 0),
(243, 27, 'Huyện Vị Thủy', 0, 0),
(244, 50, 'Thành phố Tây Ninh', 0, 0),
(245, 50, 'Huyện Tân Biên', 0, 0),
(246, 50, 'Huyện Tân Châu', 0, 0),
(247, 50, 'Huyện Dương Minh Châu', 0, 0),
(248, 50, 'Huyện Châu Thành', 0, 0),
(249, 50, 'Huyện Hòa Thành', 0, 0),
(250, 50, 'Huyện Bến Cầu', 0, 0),
(251, 50, 'Huyện Gò Dầu', 0, 0),
(252, 50, 'Huyện Trảng Bàng', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `buddhismtv_event`
--

CREATE TABLE IF NOT EXISTS `buddhismtv_event` (
  `id` bigint(11) NOT NULL,
  `id_pagoda` bigint(11) NOT NULL,
  `name` varchar(150) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `date` datetime NOT NULL,
  `content` varchar(250) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_pagoda` (`id_pagoda`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `buddhismtv_event`
--

INSERT INTO `buddhismtv_event` (`id`, `id_pagoda`, `name`, `date`, `content`) VALUES
(635400006135513720, 18, 'Tào Tháo 1', '2014-07-03 16:10:05', 'Xảo kế thử Tôn Quyền'),
(635400344401571432, 18, 'Chu Du', '2014-07-04 01:33:51', 'Thử tài Gia Cát');

-- --------------------------------------------------------

--
-- Table structure for table `buddhismtv_monk`
--

CREATE TABLE IF NOT EXISTS `buddhismtv_monk` (
  `id` bigint(20) NOT NULL,
  `name` varchar(150) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `alias` varchar(150) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `birthday` datetime NOT NULL,
  `note` varchar(250) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `picture` varchar(150) NOT NULL,
  `viewed` int(20) NOT NULL,
  `rated` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `buddhismtv_monk`
--

INSERT INTO `buddhismtv_monk` (`id`, `name`, `alias`, `birthday`, `note`, `picture`, `viewed`, `rated`) VALUES
(2, 'Thích Phước Tiến', '', '2014-07-05 00:00:00', '', '', 1, 2),
(3, 'Thích Trí Huệ', '', '2014-07-05 00:00:00', '', '', 1, 2),
(4, 'Thích Thiện Thuận', '', '2014-07-05 00:00:00', '', '', 1, 2),
(5, 'Thích Tuệ Hải', '', '2014-07-05 00:00:00', '', '', 1, 2),
(6, 'Đại Đức Thích Minh Thành', '', '2014-07-05 00:00:00', '', '', 1, 2),
(7, 'Đại Đức Thích Thiện Xuân', '', '2014-07-05 00:00:00', '', '', 1, 2),
(8, 'Thích Nhật Từ', '', '2014-07-05 00:00:00', '', '', 1, 2),
(9, 'Thích Thiện Minh', '', '2014-07-05 00:00:00', '', '', 1, 2),
(10, 'Thích Bửu Chánh', '', '2014-07-05 00:00:00', '', '', 1, 2),
(11, 'Thích Chánh Định', '', '2014-07-05 00:00:00', '', '', 1, 2),
(12, 'Minh Giác', '', '2014-07-05 00:00:00', '', '', 1, 2),
(13, 'Thích Kim Triệu', '', '2014-07-05 00:00:00', '', '', 1, 2),
(14, 'Khánh Hỷ', '', '2014-07-05 00:00:00', '', '', 1, 2),
(15, 'Pháp Chất', '', '2014-07-05 00:00:00', '', '', 1, 2),
(16, 'Thích Giác Giới', '', '2014-07-05 00:00:00', '', '', 1, 2),
(17, 'Tịnh Không', '', '2014-07-05 00:00:00', '', '', 1, 2),
(18, 'Thích Pháp Hòa', '', '2014-07-05 00:00:00', '', '', 1, 2),
(19, 'Thích Thanh Từ', '', '2014-07-05 00:00:00', '', '', 1, 2),
(20, 'Thích Thiện Xuân', '', '2014-07-05 00:00:00', '', '', 1, 2),
(21, 'Thiền Sư Zatila', '', '2014-07-05 00:00:00', '', '', 1, 2),
(22, 'Thích Chân Quang', '', '2014-07-05 00:00:00', '', '', 1, 2),
(23, 'Thích Quang Thạnh', '', '2014-07-05 00:00:00', '', '', 1, 2),
(24, 'Thích Tâm Đức', '', '2014-07-05 00:00:00', '', '', 1, 2),
(25, 'Thích Trí Quảng', '', '2014-07-05 00:00:00', '', '', 1, 2),
(26, 'Thích Trí Thoát', '', '2014-07-05 00:00:00', '', '', 1, 2),
(27, 'Thích Tuyên Hóa', '', '2014-07-05 00:00:00', '', '', 1, 2),
(635401746898356294, 'A1', 'B1', '2014-07-05 16:30:50', 'C1', 'D1', 11, 21);

-- --------------------------------------------------------

--
-- Table structure for table `buddhismtv_pagoda`
--

CREATE TABLE IF NOT EXISTS `buddhismtv_pagoda` (
  `id` bigint(11) NOT NULL,
  `id_province` bigint(11) NOT NULL,
  `id_district` bigint(20) NOT NULL,
  `name` varchar(150) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(150) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `latitude` float NOT NULL,
  `longitude` float NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `buddhismtv_pagoda`
--

INSERT INTO `buddhismtv_pagoda` (`id`, `id_province`, `id_district`, `name`, `address`, `latitude`, `longitude`) VALUES
(1, 1, 1, 'Chùa Bình Minh 2', '234 TX Bình Minh', 2, 2),
(18, 1, 1, 'Chùa Long Viễn', 'F4 Vĩnh Long', 1, 1),
(19, 1, 1, 'Chùa Tiên Châu', 'Long Hồ Vĩnh Long', 0, 2),
(20, 1, 1, 'Chùa Giác Thiên', 'F4 Vĩnh Long', 1, 3),
(21, 1, 1, 'Chùa Thiên Quang', 'Bình Dương', 1, 4),
(22, 1, 1, 'Chùa Bình Minh 1', '123 TX Bình Minh', 1, 2),
(635399803860324241, 1, 1, 'Chùa Q1', 'Quận 1', 12, 23);

-- --------------------------------------------------------

--
-- Table structure for table `buddhismtv_province`
--

CREATE TABLE IF NOT EXISTS `buddhismtv_province` (
  `id` bigint(11) NOT NULL,
  `name` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `latitude` float NOT NULL,
  `longitude` float NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `buddhismtv_province`
--

INSERT INTO `buddhismtv_province` (`id`, `name`, `latitude`, `longitude`) VALUES
(1, 'TP HCM', 0, 0),
(2, 'Hà Nội', 0, 0),
(3, 'Cần Thơ', 0, 0),
(4, 'An Giang', 0, 0),
(5, 'Bà Rịa - Vũng Tàu', 0, 0),
(6, 'Bắc Giang', 0, 0),
(7, 'Bắc Kạn', 0, 0),
(8, 'Bạc Liêu', 0, 0),
(9, 'Bắc Ninh', 0, 0),
(10, 'Bến Tre', 0, 0),
(11, 'Bình Định', 0, 0),
(12, 'Bình Dương', 0, 0),
(13, 'Bình Phước', 0, 0),
(14, 'Bình Thuận', 0, 0),
(15, 'Cà Mau', 0, 0),
(16, 'Cao Bằng', 0, 0),
(17, 'Đắk Lắk', 0, 0),
(18, 'Đắk Nông', 0, 0),
(19, 'Điện Biên', 0, 0),
(20, 'Đồng Nai', 0, 0),
(21, 'Đồng Tháp', 0, 0),
(22, 'Gia Lai', 0, 0),
(23, 'Hà Giang', 0, 0),
(24, 'Hà Nam', 0, 0),
(25, 'Hà Tĩnh', 0, 0),
(26, 'Hải Dương', 0, 0),
(27, 'Hậu Giang', 0, 0),
(28, 'Hòa Bình', 0, 0),
(29, 'Hưng Yên', 0, 0),
(30, 'Khánh Hòa', 0, 0),
(31, 'Kiên Giang', 0, 0),
(32, 'Kon Tum', 0, 0),
(33, 'Lai Châu', 0, 0),
(34, 'Lâm Đồng', 0, 0),
(35, 'Lạng Sơn', 0, 0),
(36, 'Lào Cai', 0, 0),
(37, 'Long An', 0, 0),
(38, 'Nam Định', 0, 0),
(39, 'Nghệ An', 0, 0),
(40, 'Ninh Bình', 0, 0),
(41, 'Ninh Thuận', 0, 0),
(42, 'Phú Thọ', 0, 0),
(43, 'Quảng Bình', 0, 0),
(44, 'Quảng Nam', 0, 0),
(45, 'Quảng Ngãi', 0, 0),
(46, 'Quảng Ninh', 0, 0),
(47, 'Quảng Trị', 0, 0),
(48, 'Sóc Trăng', 0, 0),
(49, 'Sơn La', 0, 0),
(50, 'Tây Ninh', 0, 0),
(51, 'Thái Bình', 0, 0),
(52, 'Thái Nguyên', 0, 0),
(53, 'Thanh Hóa', 0, 0),
(54, 'Thừa Thiên Huế', 0, 0),
(55, 'Tiền Giang', 0, 0),
(56, 'Trà Vinh', 0, 0),
(57, 'Tuyên Quang', 0, 0),
(58, 'Vĩnh Long', 0, 0),
(59, 'Vĩnh Phúc', 0, 0),
(60, 'Yên Bái', 0, 0),
(61, 'Phú Yên', 0, 0),
(62, 'Đà Nẵng', 0, 0),
(63, 'Hải Phòng', 0, 0);
