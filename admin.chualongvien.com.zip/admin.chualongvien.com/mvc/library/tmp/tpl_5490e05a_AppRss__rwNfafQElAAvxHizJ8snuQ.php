<?php 
function tpl_5490e05a_AppRss__rwNfafQElAAvxHizJ8snuQ(PHPTAL $tpl, PHPTAL_Context $ctx) {
$_thistpl = $tpl ;
$_translator = $tpl->getTranslator() ;
/* tag "documentElement" from line 1 */ ;
$ctx->setDocType('<!DOCTYPE html>',false) ;
?>

<?php /* tag "html" from line 2 */; ?>
<html lang="en">
	<?php /* tag "head" from line 3 */; ?>
<head>
		<?php 
/* tag "span" from line 4 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('mAdmin.xhtml/IncludeMETA', $_thistpl) ;
$ctx->popSlots() ;
?>

		<?php 
/* tag "span" from line 5 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('mAdmin.xhtml/IncludeCSS', $_thistpl) ;
$ctx->popSlots() ;
?>

	</head>
	<?php /* tag "body" from line 7 */; ?>
<body>
		<?php 
/* tag "div" from line 8 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('mAdmin.xhtml/Header', $_thistpl) ;
$ctx->popSlots() ;
?>

		<?php 
/* tag "div" from line 9 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('mAdmin.xhtml/UserNavigation', $_thistpl) ;
$ctx->popSlots() ;
?>
		
		<?php 
/* tag "div" from line 10 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('mAdmin.xhtml/Sidebar', $_thistpl) ;
$ctx->popSlots() ;
?>
			
		<?php /* tag "div" from line 11 */; ?>
<div id="content">
			<?php /* tag "div" from line 12 */; ?>
<div id="content-header">
				<?php /* tag "h1" from line 13 */; ?>
<h1><?php echo phptal_escape($ctx->Title); ?>
</h1>
				<?php /* tag "div" from line 14 */; ?>
<div class="btn-group">
					<?php /* tag "a" from line 15 */; ?>
<a href="/app/rss/ins/load" class="btn btn-success sinleins"><?php /* tag "i" from line 15 */; ?>
<i class="glyphicon glyphicon-plus"> Thêm mới</i></a>
				</div>
			</div>
			<?php 
/* tag "div" from line 18 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('mAdmin.xhtml/Breadcrumb', $_thistpl) ;
$ctx->popSlots() ;
?>

			<?php /* tag "div" from line 19 */; ?>
<div class="container-fluid">
				<?php /* tag "div" from line 20 */; ?>
<div class="row">
					<?php /* tag "div" from line 21 */; ?>
<div class="col-12">
						<?php /* tag "div" from line 22 */; ?>
<div class="widget-box">
							<?php /* tag "div" from line 23 */; ?>
<div class="widget-content nopadding">
								<?php /* tag "table" from line 24 */; ?>
<table class="table table-bordered table-striped table-hover">
									<?php /* tag "thead" from line 25 */; ?>
<thead>
										<?php /* tag "tr" from line 26 */; ?>
<tr>
											<?php /* tag "th" from line 27 */; ?>
<th width="32">STT</th>
											<?php /* tag "th" from line 28 */; ?>
<th><?php /* tag "div" from line 28 */; ?>
<div class="text-left">Web Gốc</div></th>
											<?php /* tag "th" from line 29 */; ?>
<th><?php /* tag "div" from line 29 */; ?>
<div class="text-left">Địa chỉ Web</div></th>
											<?php /* tag "th" from line 30 */; ?>
<th><?php /* tag "div" from line 30 */; ?>
<div class="text-left">Địa chỉ Rss lấy tin</div></th>
											<?php /* tag "th" from line 31 */; ?>
<th><?php /* tag "div" from line 31 */; ?>
<div class="text-left">Thể Loại</div></th>
											<?php /* tag "th" from line 32 */; ?>
<th><?php /* tag "div" from line 32 */; ?>
<div class="text-left">Khả dụng</div></th>
											<?php /* tag "th" from line 33 */; ?>
<th><?php /* tag "div" from line 33 */; ?>
<div class="text-left">Lấy Tin tức</div></th>
											<?php /* tag "th" from line 34 */; ?>
<th width="32"></th>
										</tr>
									</thead>
									<?php /* tag "tbody" from line 37 */; ?>
<tbody>
										<?php 
/* tag "tr" from line 38 */ ;
$_tmp_1 = $ctx->repeat ;
$_tmp_1->Rss = new PHPTAL_RepeatController($ctx->RssAll)
 ;
$ctx = $tpl->pushContext() ;
foreach ($_tmp_1->Rss as $ctx->Rss): ;
?>
<tr class="content-rows">
											<?php /* tag "td" from line 39 */; ?>
<td width="32" align="center"><?php /* tag "div" from line 39 */; ?>
<div><?php echo phptal_escape($ctx->path($ctx->repeat, 'Rss/number')); ?>
</div></td>											
											<?php /* tag "td" from line 40 */; ?>
<td align="left">
												<?php 
/* tag "a" from line 41 */ ;
if (null !== ($_tmp_2 = ($ctx->path($ctx->Rss, 'getURLUpdLoad')))):  ;
$_tmp_2 = ' href="'.phptal_escape($_tmp_2).'"' ;
else:  ;
$_tmp_2 = '' ;
endif ;
?>
<a<?php echo $_tmp_2 ?>
><?php echo phptal_escape($ctx->path($ctx->Rss, 'getName')); ?>
</a>
											</td>
											<?php /* tag "td" from line 43 */; ?>
<td align="left"><?php /* tag "div" from line 43 */; ?>
<div><?php echo phptal_escape($ctx->path($ctx->Rss, 'getWeburl')); ?>
</div></td>
											<?php /* tag "td" from line 44 */; ?>
<td align="left"><?php /* tag "div" from line 44 */; ?>
<div><?php echo phptal_escape($ctx->path($ctx->Rss, 'getRssurl')); ?>
</div></td>
											<?php /* tag "td" from line 45 */; ?>
<td align="left"><?php /* tag "div" from line 45 */; ?>
<div><?php echo phptal_escape($ctx->path($ctx->Rss, 'getCategoryVideo/getName')); ?>
</div></td>
											<?php /* tag "td" from line 46 */; ?>
<td align="left"><?php /* tag "div" from line 46 */; ?>
<div><?php echo phptal_escape($ctx->path($ctx->Rss, 'getEnablePrint')); ?>
</div></td>
											<?php /* tag "td" from line 47 */; ?>
<td align="left">
												<?php 
/* tag "a" from line 48 */ ;
if (null !== ($_tmp_2 = ($ctx->path($ctx->Rss, 'getURLPublishNews')))):  ;
$_tmp_2 = ' href="'.phptal_escape($_tmp_2).'"' ;
else:  ;
$_tmp_2 = '' ;
endif ;
?>
<a<?php echo $_tmp_2 ?>
>Lấy tin tức</a>
											</td>
											<?php /* tag "td" from line 50 */; ?>
<td width="32" class="center"><?php 
/* tag "a" from line 50 */ ;
if (null !== ($_tmp_2 = ($ctx->path($ctx->Rss, 'getId')))):  ;
$_tmp_2 = ' data-id="'.phptal_escape($_tmp_2).'"' ;
else:  ;
$_tmp_2 = '' ;
endif ;
?>
<a class="remove-item" href="#DialogDel" data-toggle="modal"<?php echo $_tmp_2 ?>
><?php /* tag "i" from line 50 */; ?>
<i class="glyphicon glyphicon-remove"></i></a></td>
										</tr><?php 
endforeach ;
$ctx = $tpl->popContext() ;
?>

									</tbody>
								</table>								
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
								
		<?php 
/* tag "div" from line 61 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('mAdmin.xhtml/Footer', $_thistpl) ;
$ctx->popSlots() ;
?>

		<?php 
/* tag "div" from line 62 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('mDialog.xhtml/DialogDel', $_thistpl) ;
$ctx->popSlots() ;
?>

		<?php 
/* tag "div" from line 63 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('mAdmin.xhtml/SignoutDialog', $_thistpl) ;
$ctx->popSlots() ;
?>

		<?php 
/* tag "span" from line 64 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('mAdmin.xhtml/IncludeJS', $_thistpl) ;
$ctx->popSlots() ;
?>

		<?php /* tag "script" from line 65 */; ?>
<script type="text/javascript">
		/*<![CDATA[*/
			//-----------------------------------------------------------------------------------
			//Delete 1 CategoryVideo			
			//-----------------------------------------------------------------------------------
		
			
			$('.remove-item').click(function(){
				$('#URLDelButton').attr('alt', $(this).attr('data-id'));
			});
			//Khi người dùng Click vào nút URLDelButton thì tiến  hành gọi Ajax xóa tự động
			$('#URLDelButton').click(function(){			
				var URL = "/object/del/RssLink/" + $(this).attr('alt');
				$.ajax({
					type: "POST",
					url: URL,
					success: function(msg){
						location.reload();
					}
				});
			});
									
						
		/*]]>*/
		</script>
	</body>
</html><?php 
/* end */ ;

}

?>
<?php /* 
*** DO NOT EDIT THIS FILE ***

Generated by PHPTAL from D:\AppWebServer\SPN_VPS\spnvps\admin.chualongvien.com\mvc\templates\AppRss.html (edit that file instead) */; ?>