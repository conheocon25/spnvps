<?php 
function tpl_54462aec_AppCategoryNews__AfVdniD5975i5qAN1pRX3w(PHPTAL $tpl, PHPTAL_Context $ctx) {
$_thistpl = $tpl ;
$_translator = $tpl->getTranslator() ;
/* tag "documentElement" from line 1 */ ;
$ctx->setDocType('<!DOCTYPE html>',false) ;
?>

<?php /* tag "html" from line 2 */; ?>
<html lang="en">
	<?php /* tag "head" from line 3 */; ?>
<head>
		<?php 
/* tag "span" from line 4 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('mAdmin.xhtml/IncludeMETA', $_thistpl) ;
$ctx->popSlots() ;
?>

		<?php 
/* tag "span" from line 5 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('mAdmin.xhtml/IncludeCSS', $_thistpl) ;
$ctx->popSlots() ;
?>

	</head>
	<?php /* tag "body" from line 7 */; ?>
<body>
		<?php 
/* tag "div" from line 8 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('mAdmin.xhtml/Header', $_thistpl) ;
$ctx->popSlots() ;
?>

		<?php 
/* tag "div" from line 9 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('mAdmin.xhtml/UserNavigation', $_thistpl) ;
$ctx->popSlots() ;
?>

		<?php 
/* tag "div" from line 10 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('mAdmin.xhtml/Sidebar', $_thistpl) ;
$ctx->popSlots() ;
?>
		
		<?php /* tag "div" from line 11 */; ?>
<div id="content">
			<?php /* tag "div" from line 12 */; ?>
<div id="content-header">
				<?php /* tag "h1" from line 13 */; ?>
<h1><?php echo phptal_escape($ctx->Title); ?>
</h1>
				<?php /* tag "div" from line 14 */; ?>
<div class="btn-group">
					<?php /* tag "button" from line 15 */; ?>
<button id="insertObject" href="#insertDialog" data-toggle="modal" class="btn btn-success sinleins"><?php /* tag "i" from line 15 */; ?>
<i class="glyphicon glyphicon-plus"> Thêm mới</i></button>
				</div>
			</div>
			<?php 
/* tag "div" from line 18 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('mAdmin.xhtml/Breadcrumb', $_thistpl) ;
$ctx->popSlots() ;
?>

			<?php /* tag "div" from line 19 */; ?>
<div class="container-fluid">
				<?php /* tag "div" from line 20 */; ?>
<div class="row">
					<?php /* tag "div" from line 21 */; ?>
<div class="col-12">
						<?php /* tag "div" from line 22 */; ?>
<div class="widget-box">
							<?php /* tag "div" from line 23 */; ?>
<div class="widget-content nopadding">
								<?php /* tag "table" from line 24 */; ?>
<table class="table table-bordered table-striped table-hover">
									<?php /* tag "thead" from line 25 */; ?>
<thead>
										<?php /* tag "tr" from line 26 */; ?>
<tr>
											<?php /* tag "th" from line 27 */; ?>
<th>STT</th>
											<?php /* tag "th" from line 28 */; ?>
<th><?php /* tag "div" from line 28 */; ?>
<div class="text-left">TÊN</div></th>
											<?php /* tag "th" from line 29 */; ?>
<th><?php /* tag "div" from line 29 */; ?>
<div class="text-left">TIN TỨC</div></th>
											<?php /* tag "th" from line 30 */; ?>
<th></th>
										</tr>
									</thead>
									<?php /* tag "tbody" from line 33 */; ?>
<tbody>
										<?php 
/* tag "tr" from line 34 */ ;
$_tmp_1 = $ctx->repeat ;
$_tmp_1->Category = new PHPTAL_RepeatController($ctx->CategoryAll)
 ;
$ctx = $tpl->pushContext() ;
foreach ($_tmp_1->Category as $ctx->Category): ;
?>
<tr class="content-rows">
											<?php /* tag "td" from line 35 */; ?>
<td width="32" align="center"><?php /* tag "div" from line 35 */; ?>
<div><?php echo phptal_escape($ctx->path($ctx->repeat, 'Category/number')); ?>
</div></td>
											<?php /* tag "td" from line 36 */; ?>
<td><?php 
/* tag "a" from line 36 */ ;
if (null !== ($_tmp_2 = ($ctx->path($ctx->Category, 'getId')))):  ;
$_tmp_2 = ' data-id="'.phptal_escape($_tmp_2).'"' ;
else:  ;
$_tmp_2 = '' ;
endif ;
?>
<a class="updateObject" href="#updateDialog" data-toggle="modal" data-name="CategoryNews"<?php echo $_tmp_2 ?>
><?php echo phptal_escape($ctx->path($ctx->Category, 'getName')); ?>
</a></td>										
											<?php /* tag "td" from line 37 */; ?>
<td width="120" class="text-hightlight" align="left">
												<?php 
/* tag "a" from line 38 */ ;
if (null !== ($_tmp_2 = ($ctx->path($ctx->Category, 'getURLView')))):  ;
$_tmp_2 = ' href="'.phptal_escape($_tmp_2).'"' ;
else:  ;
$_tmp_2 = '' ;
endif ;
?>
<a<?php echo $_tmp_2 ?>
>
													<?php /* tag "div" from line 39 */; ?>
<div>Số tin (<?php /* tag "span" from line 39 */; ?>
<span><?php echo phptal_escape($ctx->path($ctx->Category, 'getNews/count')); ?>
</span>)</div>
												</a>
											</td>
											<?php /* tag "td" from line 42 */; ?>
<td width="32" class="center"><?php 
/* tag "a" from line 42 */ ;
if (null !== ($_tmp_2 = ($ctx->path($ctx->Category, 'getId')))):  ;
$_tmp_2 = ' data-id="'.phptal_escape($_tmp_2).'"' ;
else:  ;
$_tmp_2 = '' ;
endif ;
?>
<a class="deleteObject" href="#deleteDialog" data-toggle="modal"<?php echo $_tmp_2 ?>
><?php /* tag "i" from line 42 */; ?>
<i class="glyphicon glyphicon-remove"></i></a></td>
										</tr><?php 
endforeach ;
$ctx = $tpl->popContext() ;
?>

									</tbody>
								</table>
								<?php /* tag "center" from line 46 */; ?>
<center>
									<?php /* tag "ul" from line 47 */; ?>
<ul class="pagination">
										<?php 
/* tag "li" from line 48 */ ;
$_tmp_2 = $ctx->repeat ;
$_tmp_2->P = new PHPTAL_RepeatController($ctx->path($ctx->PN, 'getPages'))
 ;
$ctx = $tpl->pushContext() ;
foreach ($_tmp_2->P as $ctx->P): ;
?>
<li><?php 
/* tag "a" from line 48 */ ;
if (null !== ($_tmp_1 = ($ctx->path($ctx->P, 'getURL')))):  ;
$_tmp_1 = ' href="'.phptal_escape($_tmp_1).'"' ;
else:  ;
$_tmp_1 = '' ;
endif ;
?>
<a<?php echo $_tmp_1 ?>
><?php echo phptal_escape($ctx->path($ctx->P, 'getName')); ?>
</a></li><?php 
endforeach ;
$ctx = $tpl->popContext() ;
?>

									</ul>
								</center>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		
		<!-- INSERT DIALOG  -->
		<?php /* tag "div" from line 59 */; ?>
<div id="insertDialog" class="modal fade">
			<?php /* tag "div" from line 60 */; ?>
<div class="modal-dialog">
				<?php /* tag "div" from line 61 */; ?>
<div class="modal-content">
					<?php /* tag "div" from line 62 */; ?>
<div class="modal-header">
						<?php /* tag "h3" from line 63 */; ?>
<h3><?php /* tag "i" from line 63 */; ?>
<i class="glyphicon glyphicon-th modal-icon"></i> THÊM DANH MỤC MỚI</h3>
					</div>
					<?php /* tag "div" from line 65 */; ?>
<div class="form-horizontal">
						<?php /* tag "div" from line 66 */; ?>
<div class="modal-body">
							<?php /* tag "div" from line 67 */; ?>
<div class="form-group">
								<?php /* tag "label" from line 68 */; ?>
<label class="control-label">Tên</label>
								<?php /* tag "div" from line 69 */; ?>
<div class="controls">
									<?php /* tag "input" from line 70 */; ?>
<input id="iName" name="Name" type="text" class="form-control input-small"/>
								</div>
							</div>
						</div>
						<?php /* tag "div" from line 74 */; ?>
<div class="modal-footer">
							<?php /* tag "button" from line 75 */; ?>
<button id="insertButton" class="btn btn-primary btn-small" type="submit"><?php /* tag "i" from line 75 */; ?>
<i class="glyphicons-download_alt"></i> Lưu</button>
							<?php /* tag "button" from line 76 */; ?>
<button data-dismiss="modal" class="btn btn-default btn-small"><?php /* tag "i" from line 76 */; ?>
<i class="glyphicons-undo"></i> Hủy</button>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- END INSERT DIALOG  -->
		
		<!-- UPDATE DIALOG  -->
		<?php /* tag "div" from line 85 */; ?>
<div id="updateDialog" class="modal fade">
			<?php /* tag "div" from line 86 */; ?>
<div class="modal-dialog">
				<?php /* tag "div" from line 87 */; ?>
<div class="modal-content">
					<?php /* tag "div" from line 88 */; ?>
<div class="modal-header">
						<?php /* tag "h3" from line 89 */; ?>
<h3><?php /* tag "i" from line 89 */; ?>
<i class="glyphicon glyphicon-th modal-icon"></i>CHỈNH SỬA DANH MỤC</h3>
					</div>
					<?php /* tag "div" from line 91 */; ?>
<div class="form-horizontal">
						<?php /* tag "div" from line 92 */; ?>
<div class="modal-body">
							<?php /* tag "div" from line 93 */; ?>
<div class="form-group">
								<?php /* tag "label" from line 94 */; ?>
<label class="control-label">Tên</label>
								<?php /* tag "div" from line 95 */; ?>
<div class="controls">
									<?php /* tag "input" from line 96 */; ?>
<input id="uName" name="Name" type="text" class="form-control input-small"/>
								</div>
							</div>
						</div>									
						<?php /* tag "div" from line 100 */; ?>
<div class="modal-footer">
							<?php /* tag "button" from line 101 */; ?>
<button id="updateButton" class="btn btn-primary btn-small" type="submit"><?php /* tag "i" from line 101 */; ?>
<i class="glyphicons-download_alt"></i> Lưu</button>
							<?php /* tag "button" from line 102 */; ?>
<button data-dismiss="modal" class="btn btn-default btn-small"><?php /* tag "i" from line 102 */; ?>
<i class="glyphicons-undo"></i> Hủy</button>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- END UPDATE DIALOG  -->
		
		<?php 
/* tag "div" from line 110 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('mAdmin.xhtml/Footer', $_thistpl) ;
$ctx->popSlots() ;
?>

		<?php 
/* tag "div" from line 111 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('mDialog.xhtml/DialogDel', $_thistpl) ;
$ctx->popSlots() ;
?>

		<?php 
/* tag "div" from line 112 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('mAdmin.xhtml/SignoutDialog', $_thistpl) ;
$ctx->popSlots() ;
?>

		<?php 
/* tag "span" from line 113 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('mAdmin.xhtml/IncludeJS', $_thistpl) ;
$ctx->popSlots() ;
?>

		<?php /* tag "script" from line 114 */; ?>
<script type="text/javascript">
		/*<![CDATA[*/
			/* ---------------------------------------------------------------------------- */
			/* INSERT CATEGORY NEWS															*/
			/* ---------------------------------------------------------------------------- */
			$('#insertButton').click(function(){
				var URL = "/object/ins/CategoryNews";
				var Data = [];
				Data[0] = 'null';
				Data[1] = $('#iName').val();
				Data[2] = '0';
				Data[3] = '';
				$.ajax({
					type: "POST",
					data: {Data:Data},
					url: URL,
					success: function(msg){
						location.reload();
					}
				});
			});
			$("#insertDialog").on('show.bs.modal', function(event){
				window.setTimeout(
					function(){$(event.currentTarget).find('input#iName').first().focus()},
					0500
				);
			});
			
			/* ---------------------------------------------------------------------------- */
			/* UPDATE PROJECT																*/
			/* ---------------------------------------------------------------------------- */
			$('.updateObject').click(function(){
				var url = "/object/load/CategoryNews/" + $(this).attr('data-id');
				$.getJSON(url, function(data){
					$('#updateButton').attr('alt', data.Id);
					$('#uName').attr('value', data.Name);
					$('#uDescription').attr('value', data.Description);
				});
			});
			$('#updateButton').click(function(){
				var URL = "/object/upd/CategoryNews";
				var Data = [];
				Data[0] = $('#updateButton').attr('alt');
				Data[1] = $('#uName').val();
				Data[2] = '0';
				Data[3] = '0';
				$.ajax({
					type: "POST",
					data: {Data:Data},
					url: URL,
					success: function(msg){
						location.reload();
					}
				});
			});
			$("#updateDialog").on('show.bs.modal', function(event){
				window.setTimeout(
					function(){$(event.currentTarget).find('input#uName').first().focus()},
					0500
				);
			});
						
			/* ---------------------------------------------------------------------------- */
			/* DELETE CATEGORY NEWS															*/
			/* ---------------------------------------------------------------------------- */
			$('.deleteObject').click(function(){
				$('#deleteButton').attr('alt', $(this).attr('data-id'));
			});
			$('#deleteButton').click(function(){
				var URL = "/object/del/CategoryNews/" + $(this).attr('alt');
				$.ajax({
					type: "POST",					
					url: URL,
					success: function(msg){
						location.reload();
					}
				});
			});
		/*]]>*/
		</script>
	</body>
</html><?php 
/* end */ ;

}

?>
<?php /* 
*** DO NOT EDIT THIS FILE ***

Generated by PHPTAL from D:\AppWebServer\SPN_VPS\spnvps\admin.chualongvien.com\mvc\templates\AppCategoryNews.html (edit that file instead) */; ?>