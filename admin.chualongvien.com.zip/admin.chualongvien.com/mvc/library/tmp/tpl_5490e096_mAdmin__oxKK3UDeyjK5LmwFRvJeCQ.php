<?php 
function tpl_5490e096_mAdmin__oxKK3UDeyjK5LmwFRvJeCQ_SignoutDialog(PHPTAL $_thistpl, PHPTAL $tpl) {
$tpl = clone $tpl ;
$ctx = $tpl->getContext() ;
$_translator = $tpl->getTranslator() ;
?>
<div id="signoutDialog" class="modal fade">
		<?php /* tag "div" from line 175 */; ?>
<div class="modal-dialog">
			<?php /* tag "div" from line 176 */; ?>
<div class="modal-content">
				<?php /* tag "div" from line 177 */; ?>
<div class="modal-header"><?php /* tag "h3" from line 177 */; ?>
<h3>Đăng xuất</h3></div>
				<?php /* tag "div" from line 178 */; ?>
<div class="modal-body">
					<?php /* tag "p" from line 179 */; ?>
<p>Bạn có chắc muốn thoát khỏi trang quản lý ?</p>
				</div>
				<?php /* tag "div" from line 181 */; ?>
<div class="modal-footer">
					<?php /* tag "form" from line 182 */; ?>
<form action="/signout/exe" method="post">
						<?php /* tag "button" from line 183 */; ?>
<button type="submit" class="btn btn-primary btn-small">OK</button>
						<?php /* tag "button" from line 184 */; ?>
<button data-dismiss="modal" class="btn btn-default btn-small">Không</button>
					</form>
				</div>
			</div>
		</div>
	</div><?php 
}

 ?>
<?php 
function tpl_5490e096_mAdmin__oxKK3UDeyjK5LmwFRvJeCQ_Footer(PHPTAL $_thistpl, PHPTAL $tpl) {
$tpl = clone $tpl ;
$ctx = $tpl->getContext() ;
$_translator = $tpl->getTranslator() ;
?>
<div class="row">
		<?php /* tag "div" from line 166 */; ?>
<div id="footer" class="col-12" style="text-align:right; padding-right:20px;">
			2009 - 2014 &copy; <?php /* tag "a" from line 167 */; ?>
<a href="https://www.spn-soft.com">SPN Group</a>
		</div>
	</div><?php 
}

 ?>
<?php 
function tpl_5490e096_mAdmin__oxKK3UDeyjK5LmwFRvJeCQ_Breadcrumb(PHPTAL $_thistpl, PHPTAL $tpl) {
$tpl = clone $tpl ;
$ctx = $tpl->getContext() ;
$_translator = $tpl->getTranslator() ;
?>
<div id="breadcrumb">
		<?php /* tag "a" from line 157 */; ?>
<a href="/app" title="Về trang chủ Website" class="tip-bottom"><?php /* tag "i" from line 157 */; ?>
<i class="glyphicon glyphicon-home"></i> QUẢN LÝ</a>
		<?php 
/* tag "a" from line 158 */ ;
$_tmp_1 = $ctx->repeat ;
$_tmp_1->Item = new PHPTAL_RepeatController($ctx->Navigation)
 ;
$ctx = $tpl->pushContext() ;
foreach ($_tmp_1->Item as $ctx->Item): ;
if (null !== ($_tmp_3 = ($ctx->Item[1]))):  ;
$_tmp_3 = ' href="'.phptal_escape($_tmp_3).'"' ;
else:  ;
$_tmp_3 = '' ;
endif ;
if (null !== ($_tmp_2 = ('Về trang '.$ctx->Item[0]))):  ;
$_tmp_2 = ' title="'.phptal_escape($_tmp_2).'"' ;
else:  ;
$_tmp_2 = '' ;
endif ;
?>
<a class="tip-bottom"<?php echo $_tmp_3 ?>
<?php echo $_tmp_2 ?>
><?php echo phptal_escape($ctx->Item[0]); ?>
</a><?php 
endforeach ;
$ctx = $tpl->popContext() ;
?>

		<?php /* tag "a" from line 159 */; ?>
<a class="current"><?php echo phptal_escape($ctx->Title); ?>
</a>
	</div><?php 
}

 ?>
<?php 
function tpl_5490e096_mAdmin__oxKK3UDeyjK5LmwFRvJeCQ_Sidebar(PHPTAL $_thistpl, PHPTAL $tpl) {
$tpl = clone $tpl ;
$ctx = $tpl->getContext() ;
$_translator = $tpl->getTranslator() ;
?>
<div id="sidebar">
		<?php /* tag "ul" from line 140 */; ?>
<ul>
			
			<?php 
/* tag "li" from line 142 */ ;
if (null !== ($_tmp_3 = ($ctx->ActiveAdmin=='News'?'active':'disable'))):  ;
$_tmp_3 = ' class="'.phptal_escape($_tmp_3).'"' ;
else:  ;
$_tmp_3 = '' ;
endif ;
?>
<li<?php echo $_tmp_3 ?>
><?php /* tag "a" from line 142 */; ?>
<a href="/app/category/news"><?php /* tag "i" from line 142 */; ?>
<i class="glyphicon glyphicon-th"></i> <?php /* tag "span" from line 142 */; ?>
<span>TIN TỨC</span> </a></li>
			<?php 
/* tag "li" from line 143 */ ;
if (null !== ($_tmp_2 = ($ctx->ActiveAdmin=='Video'?'active':'disable'))):  ;
$_tmp_2 = ' class="'.phptal_escape($_tmp_2).'"' ;
else:  ;
$_tmp_2 = '' ;
endif ;
?>
<li<?php echo $_tmp_2 ?>
><?php /* tag "a" from line 143 */; ?>
<a href="/app/btype"><?php /* tag "i" from line 143 */; ?>
<i class="glyphicon glyphicon-th"></i> <?php /* tag "span" from line 143 */; ?>
<span>THƯ VIỆN</span> </a></li>						
			<?php 
/* tag "li" from line 144 */ ;
if (null !== ($_tmp_1 = ($ctx->ActiveAdmin=='Album'?'active':'disable'))):  ;
$_tmp_1 = ' class="'.phptal_escape($_tmp_1).'"' ;
else:  ;
$_tmp_1 = '' ;
endif ;
?>
<li<?php echo $_tmp_1 ?>
><?php /* tag "a" from line 144 */; ?>
<a href="/app/album"><?php /* tag "i" from line 144 */; ?>
<i class="glyphicon glyphicon-th"></i> <?php /* tag "span" from line 144 */; ?>
<span>HÌNH ẢNH</span></a></li>
			<?php 
/* tag "li" from line 145 */ ;
if (null !== ($_tmp_3 = ($ctx->ActiveAdmin=='Event'?'active':'disable'))):  ;
$_tmp_3 = ' class="'.phptal_escape($_tmp_3).'"' ;
else:  ;
$_tmp_3 = '' ;
endif ;
?>
<li<?php echo $_tmp_3 ?>
><?php /* tag "a" from line 145 */; ?>
<a href="/app/event"><?php /* tag "i" from line 145 */; ?>
<i class="glyphicon glyphicon-th"></i> <?php /* tag "span" from line 145 */; ?>
<span>SỰ KIỆN</span></a></li>
			<?php 
/* tag "li" from line 146 */ ;
if (null !== ($_tmp_2 = ($ctx->ActiveAdmin=='Disable'?'active':'disable'))):  ;
$_tmp_2 = ' class="'.phptal_escape($_tmp_2).'"' ;
else:  ;
$_tmp_2 = '' ;
endif ;
?>
<li<?php echo $_tmp_2 ?>
><?php /* tag "a" from line 146 */; ?>
<a href="/app/disable"><?php /* tag "i" from line 146 */; ?>
<i class="glyphicon glyphicon-th"></i> <?php /* tag "span" from line 146 */; ?>
<span>VIDEO HƯ</span></a></li>
			<?php 
/* tag "li" from line 147 */ ;
if (null !== ($_tmp_1 = ($ctx->ActiveAdmin=='RssLink'?'active':'disable'))):  ;
$_tmp_1 = ' class="'.phptal_escape($_tmp_1).'"' ;
else:  ;
$_tmp_1 = '' ;
endif ;
?>
<li<?php echo $_tmp_1 ?>
><?php /* tag "a" from line 147 */; ?>
<a href="/app/rss"><?php /* tag "i" from line 147 */; ?>
<i class="glyphicon glyphicon-th"></i> <?php /* tag "span" from line 147 */; ?>
<span>RSS LẤY TIN TỨC</span> </a></li>
			<?php 
/* tag "li" from line 148 */ ;
if (null !== ($_tmp_3 = ($ctx->ActiveAdmin=='NewsRss'?'active':'disable'))):  ;
$_tmp_3 = ' class="'.phptal_escape($_tmp_3).'"' ;
else:  ;
$_tmp_3 = '' ;
endif ;
?>
<li<?php echo $_tmp_3 ?>
><?php /* tag "a" from line 148 */; ?>
<a href="/app/news/rss"><?php /* tag "i" from line 148 */; ?>
<i class="glyphicon glyphicon-th"></i> <?php /* tag "span" from line 148 */; ?>
<span>DUYỆT TIN TỨC MỚI</span> </a></li>
			<?php 
/* tag "li" from line 149 */ ;
if (null !== ($_tmp_2 = ($ctx->ActiveAdmin=='Statistic'?'active':'disable'))):  ;
$_tmp_2 = ' class="'.phptal_escape($_tmp_2).'"' ;
else:  ;
$_tmp_2 = '' ;
endif ;
?>
<li<?php echo $_tmp_2 ?>
><?php /* tag "a" from line 149 */; ?>
<a href="/app/config"><?php /* tag "i" from line 149 */; ?>
<i class="glyphicon glyphicon-th"></i> <?php /* tag "span" from line 149 */; ?>
<span>CẤU HÌNH</span></a></li>			
		</ul>
	</div><?php 
}

 ?>
<?php 
function tpl_5490e096_mAdmin__oxKK3UDeyjK5LmwFRvJeCQ_UserNavigation(PHPTAL $_thistpl, PHPTAL $tpl) {
$tpl = clone $tpl ;
$ctx = $tpl->getContext() ;
$_translator = $tpl->getTranslator() ;
?>
<div id="user-nav">
		<!--
		<ul class="btn-group">
			<li class="btn open"><a href="/trang-chu" title="Trang chủ Website - Chualongvien.com" class="tip-bottom">
				<i class="glyphicon glyphicon-home"/> <span class="text">Chualongvien.com</span>
			</a></li>
			<li class="btn open"><a title="Địa chỉ IP đang sử dụng" class="tip-bottom">
				<i class="glyphicon glyphicon-signal"/> <span class="text" tal:content="php:@\MVC\Library\Statistic::getIPPrint()"/>
			</a></li>
			<li class="btn open"><a title="Tài khoản đang sử dụng" class="tip-bottom">				
				<i class="glyphicon glyphicon-user"></i> <span class="text" tal:condition="php: @\MVC\Base\SessionRegistry::instance()->getCurrentUser()" tal:content="php: @\MVC\Base\SessionRegistry::instance()->getCurrentUser()->getEmail()"/>
			</a></li>
			<li class="btn"><a href="#signoutDialog" data-toggle="modal" title="Thoát trang quản lý" class="tip-bottom">
				<i class="glyphicon glyphicon-share-alt"/> <span class="text">Thoát</span>
			</a></li>
		</ul>
		!-->
	</div><?php 
}

 ?>
<?php 
function tpl_5490e096_mAdmin__oxKK3UDeyjK5LmwFRvJeCQ_PageBar(PHPTAL $_thistpl, PHPTAL $tpl) {
$tpl = clone $tpl ;
$ctx = $tpl->getContext() ;
$_translator = $tpl->getTranslator() ;
?>
<ul class="pagination alternate pull-right page-bar">
		<?php 
/* tag "li" from line 109 */ ;
$_tmp_1 = $ctx->repeat ;
$_tmp_1->P = new PHPTAL_RepeatController($ctx->path($ctx->PN, 'getPages'))
 ;
$ctx = $tpl->pushContext() ;
foreach ($_tmp_1->P as $ctx->P): ;
if (null !== ($_tmp_2 = ($ctx->Page==$ctx->P->getId()?'active':'disable'))):  ;
$_tmp_2 = ' class="'.phptal_escape($_tmp_2).'"' ;
else:  ;
$_tmp_2 = '' ;
endif ;
?>
<li<?php echo $_tmp_2 ?>
>
			<?php 
/* tag "a" from line 110 */ ;
if (null !== ($_tmp_3 = ($ctx->path($ctx->P, 'getURL')))):  ;
$_tmp_3 = ' href="'.phptal_escape($_tmp_3).'"' ;
else:  ;
$_tmp_3 = '' ;
endif ;
?>
<a<?php echo $_tmp_3 ?>
><?php echo phptal_escape($ctx->path($ctx->P, 'getName')); ?>
</a>
		</li><?php 
endforeach ;
$ctx = $tpl->popContext() ;
?>

	</ul><?php 
}

 ?>
<?php 
function tpl_5490e096_mAdmin__oxKK3UDeyjK5LmwFRvJeCQ_ContentHeader(PHPTAL $_thistpl, PHPTAL $tpl) {
$tpl = clone $tpl ;
$ctx = $tpl->getContext() ;
$_translator = $tpl->getTranslator() ;
?>
<div id="content-header">
		<?php /* tag "h1" from line 102 */; ?>
<h1>HỆ THỐNG QUẢN LÝ THÔNG TIN <?php /* tag "span" from line 102 */; ?>
<span><?php 
$ctx->noThrow(true) ;
if (!phptal_isempty($_tmp_2 = $ctx->path($ctx->ConfigName, 'getValue', true))):  ;
?>
<?php 
echo phptal_escape($_tmp_2) ;
else:  ;
?>
<?php 
echo 'CHÙA' ;
endif ;
$ctx->noThrow(false) ;
?>
</span></h1>
	</div><?php 
}

 ?>
<?php 
function tpl_5490e096_mAdmin__oxKK3UDeyjK5LmwFRvJeCQ_LocationBar(PHPTAL $_thistpl, PHPTAL $tpl) {
$tpl = clone $tpl ;
$ctx = $tpl->getContext() ;
$_translator = $tpl->getTranslator() ;
?>
<div id="breadcrumb">
		<?php /* tag "a" from line 93 */; ?>
<a class="tip-bottom" title="" href="/app" data-original-title="Về trang chủ"><?php /* tag "i" from line 93 */; ?>
<i class="glyphicons-shop"></i> HỆ THỐNG</a>
		<?php 
/* tag "a" from line 94 */ ;
$_tmp_1 = $ctx->repeat ;
$_tmp_1->Item = new PHPTAL_RepeatController($ctx->Navigation)
 ;
$ctx = $tpl->pushContext() ;
foreach ($_tmp_1->Item as $ctx->Item): ;
if (null !== ($_tmp_2 = ($ctx->Item[1]))):  ;
$_tmp_2 = ' href="'.phptal_escape($_tmp_2).'"' ;
else:  ;
$_tmp_2 = '' ;
endif ;
?>
<a data-original-title="Về trang này" class="tip-bottom"<?php echo $_tmp_2 ?>
><?php echo phptal_escape($ctx->Item[0]); ?>
</a><?php 
endforeach ;
$ctx = $tpl->popContext() ;
?>

		<?php /* tag "a" from line 95 */; ?>
<a class="current"><?php echo phptal_escape($ctx->Title); ?>
</a>
	</div><?php 
}

 ?>
<?php 
function tpl_5490e096_mAdmin__oxKK3UDeyjK5LmwFRvJeCQ_Header(PHPTAL $_thistpl, PHPTAL $tpl) {
$tpl = clone $tpl ;
$ctx = $tpl->getContext() ;
$_translator = $tpl->getTranslator() ;
?>
<div>
		<?php /* tag "div" from line 69 */; ?>
<div id="header">
			<?php /* tag "h1" from line 70 */; ?>
<h1><?php /* tag "a" from line 70 */; ?>
<a>Pagoda App</a></h1>
			<?php /* tag "a" from line 71 */; ?>
<a id="menu-trigger" href="#"><?php /* tag "i" from line 71 */; ?>
<i class="glyphicon glyphicon-align-justify"></i></a>	
		</div>
		<?php /* tag "div" from line 73 */; ?>
<div id="user-nav">
            <?php /* tag "ul" from line 74 */; ?>
<ul class="btn-group">
				<?php /* tag "li" from line 75 */; ?>
<li class="btn">
					<?php /* tag "a" from line 76 */; ?>
<a class="tip-bottom" data-original-title="Click để đăng nhập" href="/signin/load">
						<?php /* tag "i" from line 77 */; ?>
<i class="glyphicons-imac" style="margin-top:-5px;margin-right:5px;"></i> <?php /* tag "span" from line 77 */; ?>
<span><?php echo phptal_escape(\MVC\Library\Statistic::getIPPrint()); ?>
</span>
					</a>
				</li>
                <?php /* tag "li" from line 80 */; ?>
<li class="btn">
					<?php /* tag "a" from line 81 */; ?>
<a class="tip-bottom" data-original-title="Click để đăng xuất" href="/signout/exe">
						<?php /* tag "i" from line 82 */; ?>
<i class="glyphicon glyphicon-user"></i> <?php 
/* tag "span" from line 82 */ ;
if (\MVC\Base\SessionRegistry::instance()->getCurrentUser()):  ;
?>
<span class="text"><?php echo phptal_escape(\MVC\Base\SessionRegistry::instance()->getCurrentUser()->getEmail()); ?>
</span><?php endif; ?>

					</a>
				</li>
            </ul>
        </div>
	</div><?php 
}

 ?>
<?php 
function tpl_5490e096_mAdmin__oxKK3UDeyjK5LmwFRvJeCQ_IncludeJS(PHPTAL $_thistpl, PHPTAL $tpl) {
$tpl = clone $tpl ;
$ctx = $tpl->getContext() ;
$_translator = $tpl->getTranslator() ;
?>
<span>								
		<?php /* tag "script" from line 47 */; ?>
<script src="/mvc/templates/theme/cms/js/jquery.min.js"></script>
		<?php /* tag "script" from line 48 */; ?>
<script src="/mvc/templates/theme/cms/js/jquery-ui.custom.js"></script>
		<?php /* tag "script" from line 49 */; ?>
<script src="/mvc/templates/theme/cms/js/bootstrap.min.js"></script>
		<?php /* tag "script" from line 50 */; ?>
<script src="/mvc/templates/theme/cms/js/unicorn.js"></script>
		<?php /* tag "script" from line 51 */; ?>
<script src="/mvc/templates/theme/cms/js/jquery.jpanelmenu.min.js"></script>
		<?php /* tag "script" from line 52 */; ?>
<script src="/mvc/templates/theme/cms/js/jquery.icheck.min.js"></script>
		<?php /* tag "script" from line 53 */; ?>
<script src="/mvc/templates/theme/cms/js/select2.min.js"></script>
		<?php /* tag "script" from line 54 */; ?>
<script src="/mvc/templates/theme/cms/js/jquery.dataTables.min.js"></script>
		<?php /* tag "script" from line 55 */; ?>
<script src="/mvc/templates/theme/cms/js/unicorn.tables.js"></script>
		<?php /* tag "script" from line 56 */; ?>
<script src="/mvc/templates/theme/cms/js/jquery.gritter.min.js"></script>
		<?php /* tag "script" from line 57 */; ?>
<script src="/mvc/templates/theme/cms/js/bootstrap-datepicker.js"></script>
		<?php /* tag "script" from line 58 */; ?>
<script src="/mvc/templates/theme/cms/js/bootstrap-datepicker.vi.js"></script>
        <?php /* tag "script" from line 59 */; ?>
<script src="/mvc/templates/theme/cms/js/jquery.masonry.min.js"></script>
		<?php /* tag "script" from line 60 */; ?>
<script src="/mvc/templates/theme/cms/js/bootstrap-datetimepicker.js"></script>
		<?php /* tag "script" from line 61 */; ?>
<script src="/mvc/templates/theme/cms/js/bootstrap-datetimepicker.vi.js"></script>		
		<?php /* tag "script" from line 62 */; ?>
<script src="/mvc/templates/theme/cms/js/jquery.validate.js"></script>
	</span><?php 
}

 ?>
<?php 
function tpl_5490e096_mAdmin__oxKK3UDeyjK5LmwFRvJeCQ_IncludeCSS(PHPTAL $_thistpl, PHPTAL $tpl) {
$tpl = clone $tpl ;
$ctx = $tpl->getContext() ;
$_translator = $tpl->getTranslator() ;
?>
<span>	
		<?php /* tag "link" from line 27 */; ?>
<link rel="stylesheet" href="/mvc/templates/theme/cms/css/icheck/flat/blue.css"/>
		<?php /* tag "link" from line 28 */; ?>
<link rel="stylesheet" href="/mvc/templates/theme/cms/css/select2.css"/>
		<?php /* tag "link" from line 29 */; ?>
<link rel="stylesheet" href="/mvc/templates/theme/cms/css/bootstrap.min.css"/>
		<?php /* tag "link" from line 30 */; ?>
<link rel="stylesheet" href="/mvc/templates/theme/cms/css/bootstrap-glyphicons.css"/>
		<?php /* tag "link" from line 31 */; ?>
<link rel="stylesheet" href="/mvc/templates/theme/cms/css/glyphicons-regular.css"/>
		<?php /* tag "link" from line 32 */; ?>
<link rel="stylesheet" href="/mvc/templates/theme/cms/css/jquery-ui.css"/>
		<?php /* tag "link" from line 33 */; ?>
<link rel="stylesheet" href="/mvc/templates/theme/cms/css/unicorn.main.css"/>
		<?php /* tag "link" from line 34 */; ?>
<link rel="stylesheet" href="/mvc/templates/theme/cms/css/datepicker.css"/>
		<?php /* tag "link" from line 35 */; ?>
<link rel="stylesheet" href="/mvc/templates/theme/cms/css/datetimepicker.css"/>
		<?php /* tag "link" from line 36 */; ?>
<link rel="stylesheet" href="/mvc/templates/theme/cms/css/custom.css"/>
		<?php /* tag "link" from line 37 */; ?>
<link rel="stylesheet" href="/mvc/templates/theme/cms/css/grid-menu.css"/>
		<?php /* tag "link" from line 38 */; ?>
<link rel="stylesheet" href="/mvc/templates/theme/cms/css/jquery.gritter.css"/>
		<?php /* tag "link" from line 39 */; ?>
<link rel="stylesheet" href="/mvc/templates/theme/cms/css/gritter.css"/>
		<?php 
/* tag "link" from line 40 */ ;
if (null !== ($_tmp_1 = ('/mvc/templates/theme/cms/css/unicorn.' . \MVC\Base\SessionRegistry::instance()->getCurrentTheme() . '.css'))):  ;
$_tmp_1 = ' href="'.phptal_escape($_tmp_1).'"' ;
else:  ;
$_tmp_1 = '' ;
endif ;
?>
<link rel="stylesheet" class="skin-color"<?php echo $_tmp_1 ?>
/>
	</span><?php 
}

 ?>
<?php 
function tpl_5490e096_mAdmin__oxKK3UDeyjK5LmwFRvJeCQ_IncludeMETA(PHPTAL $_thistpl, PHPTAL $tpl) {
$tpl = clone $tpl ;
$ctx = $tpl->getContext() ;
$_translator = $tpl->getTranslator() ;
?>
<span>
		<?php /* tag "title" from line 7 */; ?>
<title><?php echo 'Hệ thống quản lý thông tin Chùa'; ?>
</title>
		<?php /* tag "base" from line 8 */; ?>
<base href="http://admin.chualongvien.com"/>

		<?php /* tag "meta" from line 10 */; ?>
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
		<?php /* tag "meta" from line 11 */; ?>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
		<?php /* tag "meta" from line 12 */; ?>
<meta http-equiv="Pragma" content="no-cache"/>
		<?php /* tag "meta" from line 13 */; ?>
<meta http-equiv="Expires" content="-1"/>
		<?php /* tag "meta" from line 14 */; ?>
<meta http-equiv="Cache-Control" content="no-cache"/>
		<?php /* tag "meta" from line 15 */; ?>
<meta name="keywords" content="Hệ thống quản lý thông tin Chùa"/>
		<?php /* tag "meta" from line 16 */; ?>
<meta name="description" content="Hệ thống quản lý thông tin Chùa"/>
		<?php /* tag "meta" from line 17 */; ?>
<meta name="page-topic" content="Hệ thống quản lý thông tin Chùa"/>
		<?php /* tag "meta" from line 18 */; ?>
<meta name="Abstract" content="Hệ thống quản lý thông tin Chùa"/>
		<?php /* tag "meta" from line 19 */; ?>
<meta name="classification" content="Hệ thống quản lý thông tin Chùa"/>
		<?php /* tag "link" from line 20 */; ?>
<link rel="shortcut icon" type="image/png" href="/data/images/app/icon.png"/>
	</span><?php 
}

 ?>
<?php 
function tpl_5490e096_mAdmin__oxKK3UDeyjK5LmwFRvJeCQ(PHPTAL $tpl, PHPTAL_Context $ctx) {
$_thistpl = $tpl ;
$_translator = $tpl->getTranslator() ;
/* tag "documentElement" from line 1 */ ;
/* tag "html" from line 1 */ ;
?>
<html lang="en" xml:lang="en">
<?php /* tag "body" from line 2 */; ?>
<body>
	<!-- ======================================================================== -->
	<!-- META TAG INCLUDE														  -->
	<!-- ======================================================================== -->
	<?php /* tag "span" from line 6 */; ?>

	
	<!-- ======================================================================== -->
	<!-- CASCADING STYLE SHEETS INCLUDE											  -->
	<!-- ======================================================================== -->
	<?php /* tag "span" from line 26 */; ?>

	
	<!-- ======================================================================== -->
	<!-- JAVASCRIPT INCLUDE														  -->
	<!-- ======================================================================== -->
	<?php /* tag "span" from line 46 */; ?>

	
	<!-- ======================================================================== -->
	<!-- HEADER																	  -->
	<!-- ======================================================================== -->
	<?php /* tag "div" from line 68 */; ?>


	<!-- ======================================================================== -->
	<!-- LOCATION BAR															  -->
	<!-- ======================================================================== -->
	<?php /* tag "div" from line 92 */; ?>

	
	<!-- ======================================================================== -->
	<!-- CONTENT HEADER															  -->
	<!-- ======================================================================== -->	
	<?php /* tag "div" from line 101 */; ?>

	
	<!-- ======================================================================== -->
	<!-- PAGE BAR																  -->
	<!-- ======================================================================== -->
	<?php /* tag "ul" from line 108 */; ?>

	
	<!-- ======================================================================== -->
	<!-- HEADER																	  -->
	<!-- ======================================================================== -->		
	<?php /* tag "div" from line 117 */; ?>

	
	<!-- ======================================================================== -->
	<!-- LEFT MENU - SIDEBAR													  -->
	<!-- ======================================================================== -->
	<?php /* tag "div" from line 139 */; ?>

	
	<!-- ======================================================================== -->
	<!-- BREADCRUMB																  -->
	<!-- ======================================================================== -->
	<?php /* tag "div" from line 156 */; ?>

	
	<!-- ======================================================================== -->
	<!-- FOOTER																	  -->
	<!-- ======================================================================== -->
	<?php /* tag "div" from line 165 */; ?>

	
	<!-- ======================================================================== -->
	<!-- SIGNOUT DIALOG															  -->
	<!-- ======================================================================== -->
	<?php /* tag "div" from line 174 */; ?>
	
		
</body>
</html><?php 
/* end */ ;

}

?>
<?php /* 
*** DO NOT EDIT THIS FILE ***

Generated by PHPTAL from D:\AppWebServer\SPN_VPS\spnvps\admin.chualongvien.com\mvc\templates\mAdmin.xhtml (edit that file instead) */; ?>