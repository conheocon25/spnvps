<?php 
function tpl_5490ee3a_AppNewsRss__raoCca4bXy5V2w48zlBp1w(PHPTAL $tpl, PHPTAL_Context $ctx) {
$_thistpl = $tpl ;
$_translator = $tpl->getTranslator() ;
/* tag "documentElement" from line 1 */ ;
$ctx->setDocType('<!DOCTYPE html>',false) ;
?>

<?php /* tag "html" from line 2 */; ?>
<html lang="en">
	<?php /* tag "head" from line 3 */; ?>
<head>
		<?php 
/* tag "span" from line 4 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('mAdmin.xhtml/IncludeMETA', $_thistpl) ;
$ctx->popSlots() ;
?>

		<?php 
/* tag "span" from line 5 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('mAdmin.xhtml/IncludeCSS', $_thistpl) ;
$ctx->popSlots() ;
?>

	</head>
	<?php /* tag "body" from line 7 */; ?>
<body>
		<?php 
/* tag "div" from line 8 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('mAdmin.xhtml/Header', $_thistpl) ;
$ctx->popSlots() ;
?>

		<?php 
/* tag "div" from line 9 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('mAdmin.xhtml/UserNavigation', $_thistpl) ;
$ctx->popSlots() ;
?>

		<?php 
/* tag "div" from line 10 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('mAdmin.xhtml/Sidebar', $_thistpl) ;
$ctx->popSlots() ;
?>
	
		
		<?php /* tag "div" from line 12 */; ?>
<div id="content">
			<?php /* tag "div" from line 13 */; ?>
<div id="content-header">
				<?php /* tag "h1" from line 14 */; ?>
<h1><?php echo phptal_escape($ctx->Title); ?>
</h1>
				<?php /* tag "div" from line 15 */; ?>
<div class="btn-group">
					<?php /* tag "div" from line 16 */; ?>
<div id="URLPublishNews" class="btn btn-success "><?php /* tag "i" from line 16 */; ?>
<i class="glyphicon glyphicon-plus"> Duyệt tin</i></div>
					<?php /* tag "span" from line 17 */; ?>
<span style="padding-left:3px"></span>
					<?php /* tag "div" from line 18 */; ?>
<div id="URLDeleteNews" class="btn btn-success "><?php /* tag "i" from line 18 */; ?>
<i class="glyphicon glyphicon-plus"> Xóa tin</i></div>
				</div>
			</div>
			<?php 
/* tag "div" from line 21 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('mAdmin.xhtml/Breadcrumb', $_thistpl) ;
$ctx->popSlots() ;
?>

			<?php /* tag "div" from line 22 */; ?>
<div class="container-fluid">
				<?php /* tag "div" from line 23 */; ?>
<div class="row">
					<?php /* tag "div" from line 24 */; ?>
<div class="col-12">
						<?php /* tag "div" from line 25 */; ?>
<div class="widget-box">
							<?php /* tag "div" from line 26 */; ?>
<div class="widget-content nopadding">
								<?php /* tag "table" from line 27 */; ?>
<table class="table table-bordered table-striped table-hover">
									<?php /* tag "thead" from line 28 */; ?>
<thead>
										<?php /* tag "tr" from line 29 */; ?>
<tr>
											<?php /* tag "th" from line 30 */; ?>
<th width="40">Duyệt<?php /* tag "input" from line 30 */; ?>
<input type="checkbox" id="title-table-checkbox" name="title-table-checkbox"/></th>
											<?php /* tag "th" from line 31 */; ?>
<th width="30px">STT</th>											
											<?php /* tag "th" from line 32 */; ?>
<th><?php /* tag "div" from line 32 */; ?>
<div class="text-left">NGÀY</div></th>
											<?php /* tag "th" from line 33 */; ?>
<th><?php /* tag "div" from line 33 */; ?>
<div class="text-left">TIÊU ĐỀ</div></th>											
											<?php /* tag "th" from line 34 */; ?>
<th><?php /* tag "div" from line 34 */; ?>
<div class="text-left">NGUỒN</div></th>											
											<?php /* tag "th" from line 35 */; ?>
<th><?php /* tag "div" from line 35 */; ?>
<div class="text-left">DANH MỤC</div></th>																						
										</tr>
									</thead>
									<?php /* tag "tbody" from line 38 */; ?>
<tbody>
										<?php 
/* tag "tr" from line 39 */ ;
$_tmp_1 = $ctx->repeat ;
$_tmp_1->News = new PHPTAL_RepeatController($ctx->NewsRssAll)
 ;
$ctx = $tpl->pushContext() ;
foreach ($_tmp_1->News as $ctx->News): ;
?>
<tr>
											<?php /* tag "td" from line 40 */; ?>
<td class="center"><?php 
/* tag "input" from line 40 */ ;
if (null !== ($_tmp_2 = ($ctx->path($ctx->News, 'getId')))):  ;
$_tmp_2 = ' data-id="'.phptal_escape($_tmp_2).'"' ;
else:  ;
$_tmp_2 = '' ;
endif ;
?>
<input class="CheckedPublish" type="checkbox"<?php echo $_tmp_2 ?>
/></td>
											<?php /* tag "td" from line 41 */; ?>
<td><?php /* tag "div" from line 41 */; ?>
<div><?php echo phptal_escape($ctx->path($ctx->repeat, 'News/number')); ?>
</div></td>											
											<?php /* tag "td" from line 42 */; ?>
<td width="90px"><?php /* tag "div" from line 42 */; ?>
<div><?php echo phptal_escape($ctx->path($ctx->News, 'getDatePrint')); ?>
</div></td>
											<?php /* tag "td" from line 43 */; ?>
<td><?php /* tag "div" from line 43 */; ?>
<div><?php echo phptal_escape($ctx->path($ctx->News, 'getTitle')); ?>
</div></td>											
											<?php /* tag "td" from line 44 */; ?>
<td><?php /* tag "div" from line 44 */; ?>
<div><?php echo phptal_escape($ctx->path($ctx->News, 'getRssLink/getName')); ?>
</div></td>											
											<?php /* tag "td" from line 45 */; ?>
<td><?php /* tag "div" from line 45 */; ?>
<div><?php echo phptal_escape($ctx->path($ctx->News, 'getRssLink/getCategoryVideo/getName')); ?>
</div></td>	
										</tr><?php 
endforeach ;
$ctx = $tpl->popContext() ;
?>

									</tbody>
								</table>	
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>

		<?php 
/* tag "div" from line 56 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('mAdmin.xhtml/Footer', $_thistpl) ;
$ctx->popSlots() ;
?>

		<?php 
/* tag "div" from line 57 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('mDialog.xhtml/DialogDel', $_thistpl) ;
$ctx->popSlots() ;
?>

		<?php 
/* tag "div" from line 58 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('mAdmin.xhtml/SignoutDialog', $_thistpl) ;
$ctx->popSlots() ;
?>

		<?php 
/* tag "span" from line 59 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('mAdmin.xhtml/IncludeJS', $_thistpl) ;
$ctx->popSlots() ;
?>

		
		<?php /* tag "script" from line 61 */; ?>
<script type="text/javascript">
		/*<![CDATA[*/
			$('#URLDeleteNews').click(function(){
				var count = 0;
				var Data = [];
				var URL = "/object/del/NewsRss/0";
				
				$(".CheckedPublish").each(function( i, obj){
					if ( $(this).is(':checked')==true ){
						count += 1;
						Data[count] = $(this).attr('data-id');
					}
				});
				
				$.ajax({
					type: "POST",
					data: {ListId:Data},
					url: URL,
					success: function(msg){
						location.reload();
					}
				});
			});
			
			$('#URLPublishNews').click(function(){
				var count = 0;
				var Data = [];
				var URL = "/app/news/published";
				
				$(".CheckedPublish").each(function( i, obj){
					if ( $(this).is(':checked')==true ){						
						Data[count] = $(this).attr('data-id');
						count += 1;
					}
				});
				alert (Data);
				$.ajax({
					type: "POST",
					data: {ListId:Data},
					url: URL,
					success: function(msg){
						location.reload();
					}
				});
			});
		/*]]>*/
		</script>
	</body>
</html><?php 
/* end */ ;

}

?>
<?php /* 
*** DO NOT EDIT THIS FILE ***

Generated by PHPTAL from D:\AppWebServer\SPN_VPS\spnvps\admin.chualongvien.com\mvc\templates\AppNewsRss.html (edit that file instead) */; ?>