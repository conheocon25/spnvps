<?php 
function tpl_549261d6_AppRssInsLoad__GNVUq82QwCju6CEcyEIIDg(PHPTAL $tpl, PHPTAL_Context $ctx) {
$_thistpl = $tpl ;
$_translator = $tpl->getTranslator() ;
/* tag "documentElement" from line 1 */ ;
$ctx->setDocType('<!DOCTYPE html>',false) ;
?>

<?php /* tag "html" from line 2 */; ?>
<html lang="en">
	<?php /* tag "head" from line 3 */; ?>
<head>
		<?php 
/* tag "span" from line 4 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('mAdmin.xhtml/IncludeMETA', $_thistpl) ;
$ctx->popSlots() ;
?>

		<?php 
/* tag "span" from line 5 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('mAdmin.xhtml/IncludeCSS', $_thistpl) ;
$ctx->popSlots() ;
?>

	</head>
	<?php /* tag "body" from line 7 */; ?>
<body>
		<?php 
/* tag "div" from line 8 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('mAdmin.xhtml/Header', $_thistpl) ;
$ctx->popSlots() ;
?>

		<?php 
/* tag "div" from line 9 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('mAdmin.xhtml/UserNavigation', $_thistpl) ;
$ctx->popSlots() ;
?>
		
		<?php /* tag "div" from line 10 */; ?>
<div id="content">
			<?php /* tag "div" from line 11 */; ?>
<div id="content-header">
				<?php /* tag "h1" from line 12 */; ?>
<h1>THÊM MỚI SỰ KIỆN</h1>
			</div>
			<?php 
/* tag "div" from line 14 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('mAdmin.xhtml/Breadcrumb', $_thistpl) ;
$ctx->popSlots() ;
?>

			<?php /* tag "div" from line 15 */; ?>
<div class="container-fluid">
				<?php /* tag "div" from line 16 */; ?>
<div class="row">
					<?php /* tag "div" from line 17 */; ?>
<div class="col-12">
						<?php /* tag "div" from line 18 */; ?>
<div class="widget-box">
							<?php /* tag "div" from line 19 */; ?>
<div class="widget-content nopadding">
								<?php /* tag "form" from line 20 */; ?>
<form class="form-horizontal" action="/app/rss/ins/exe" method="post">
									<?php /* tag "div" from line 21 */; ?>
<div class="control-group">
										<?php /* tag "label" from line 22 */; ?>
<label class="control-label" for="Title">Tên Trang Web</label>
										<?php /* tag "div" from line 23 */; ?>
<div class="controls">
											<?php /* tag "input" from line 24 */; ?>
<input type="text" id="Name" name="Name"/>
										</div>
									</div>									
									<?php /* tag "div" from line 27 */; ?>
<div class="control-group">
										<?php /* tag "label" from line 28 */; ?>
<label class="control-label" for="Weburl">Địa Chỉ Web lấy tin</label>
										<?php /* tag "div" from line 29 */; ?>
<div class="controls">											
											<?php /* tag "input" from line 30 */; ?>
<input type="text" id="Weburl" name="Weburl"/>
										</div>
									</div>
									<?php /* tag "div" from line 33 */; ?>
<div class="control-group">
										<?php /* tag "label" from line 34 */; ?>
<label class="control-label" for="Rssurl">Địa chỉ Rss lấy tin</label>
										<?php /* tag "div" from line 35 */; ?>
<div class="controls">
											<?php /* tag "input" from line 36 */; ?>
<input type="text" id="Rssurl" name="Rssurl"/>
										</div>
									</div>
									<?php /* tag "div" from line 39 */; ?>
<div class="control-group">
										<?php /* tag "label" from line 40 */; ?>
<label class="control-label" for="Type">Loại Rss</label>
										<?php /* tag "div" from line 41 */; ?>
<div class="controls">
											<?php /* tag "select" from line 42 */; ?>
<select name="Type" id="Type">
												<?php /* tag "option" from line 43 */; ?>
<option value="1"><?php /* tag "span" from line 43 */; ?>
<span>Loại 1</span></option>
												<?php /* tag "option" from line 44 */; ?>
<option value="2"><?php /* tag "span" from line 44 */; ?>
<span>Loại 2</span></option>
												<?php /* tag "option" from line 45 */; ?>
<option value="3"><?php /* tag "span" from line 45 */; ?>
<span>Loại 3</span></option>
												<?php /* tag "option" from line 46 */; ?>
<option value="4"><?php /* tag "span" from line 46 */; ?>
<span>Loại 4</span></option>
											</select>
										</div>
									</div>
									<?php /* tag "div" from line 50 */; ?>
<div class="control-group">
										<?php /* tag "label" from line 51 */; ?>
<label class="control-label" for="IdCategory">Thêm vào Danh mục tin tức</label>
										<?php /* tag "div" from line 52 */; ?>
<div class="controls">
											<?php /* tag "select" from line 53 */; ?>
<select name="IdCategory" id="IdCategory">
												<?php 
/* tag "option" from line 54 */ ;
$_tmp_1 = $ctx->repeat ;
$_tmp_1->CategoryNew = new PHPTAL_RepeatController($ctx->AllCategoryNews)
 ;
$ctx = $tpl->pushContext() ;
foreach ($_tmp_1->CategoryNew as $ctx->CategoryNew): ;
if (null !== ($_tmp_2 = ($ctx->path($ctx->CategoryNew, 'getId')))):  ;
$_tmp_2 = ' value="'.phptal_escape($_tmp_2).'"' ;
else:  ;
$_tmp_2 = '' ;
endif ;
?>
<option<?php echo $_tmp_2 ?>
>
													<?php /* tag "span" from line 55 */; ?>
<span><?php echo phptal_escape($ctx->path($ctx->CategoryNew, 'getName')); ?>
</span>
												</option><?php 
endforeach ;
$ctx = $tpl->popContext() ;
?>

											</select>
										</div>
									</div>
									<?php /* tag "div" from line 60 */; ?>
<div class="control-group">
										<?php /* tag "label" from line 61 */; ?>
<label class="control-label" for="Enable">Khả dụng</label>
										<?php /* tag "div" from line 62 */; ?>
<div class="controls">
											<?php /* tag "select" from line 63 */; ?>
<select name="Enable" id="Enable">
												<?php /* tag "option" from line 64 */; ?>
<option value="1"><?php /* tag "span" from line 64 */; ?>
<span>Áp Dụng</span></option>
												<?php /* tag "option" from line 65 */; ?>
<option value="0"><?php /* tag "span" from line 65 */; ?>
<span>Không Áp Dụng</span></option>
											</select>
										</div>
									</div>
									<?php /* tag "div" from line 69 */; ?>
<div class="form-actions">
										<?php /* tag "button" from line 70 */; ?>
<button type="submit" class="btn btn-success" value="submit-value">Lưu</button>
									</div>
								</form>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		
		<?php 
/* tag "div" from line 80 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('mAdmin.xhtml/Footer', $_thistpl) ;
$ctx->popSlots() ;
?>

		<?php 
/* tag "div" from line 81 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('mAdmin.xhtml/SignoutDialog', $_thistpl) ;
$ctx->popSlots() ;
?>

		<?php 
/* tag "span" from line 82 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('mAdmin.xhtml/IncludeJS', $_thistpl) ;
$ctx->popSlots() ;
?>

		<?php /* tag "script" from line 83 */; ?>
<script type="text/javascript" language="javascript" src="/mvc/templates/theme/cms/ckeditor/ckeditor.js"></script>
		<?php /* tag "script" from line 84 */; ?>
<script type="text/javascript">
		/*<![CDATA[*/
			/* ---------------------------------------------------------------------------- */
			/* SET TODAY FOR DATEPICKER														*/
			/* ---------------------------------------------------------------------------- */
			//THIẾT LẬP NGÀY GIỜ GIAO DỊCH
			$('#Date').datetimepicker({
				language:  'vi',
				weekStart: 1,
				todayBtn:  1,
				autoclose: 1,
				todayHighlight: 1,
				startView: 2,
				forceParse: 0,
				showMeridian: 1
			});			
		/*]]>*/
		</script>
	</body>
</html><?php 
/* end */ ;

}

?>
<?php /* 
*** DO NOT EDIT THIS FILE ***

Generated by PHPTAL from D:\AppWebServer\SPN_VPS\spnvps\admin.chualongvien.com\mvc\templates\AppRssInsLoad.html (edit that file instead) */; ?>