<?php 
function tpl_548ff07d_AppRss__rwNfafQElAAvxHizJ8snuQ(PHPTAL $tpl, PHPTAL_Context $ctx) {
$_thistpl = $tpl ;
$_translator = $tpl->getTranslator() ;
/* tag "documentElement" from line 1 */ ;
$ctx->setDocType('<!DOCTYPE html>',false) ;
?>

<?php /* tag "html" from line 2 */; ?>
<html lang="en">
	<?php /* tag "head" from line 3 */; ?>
<head>
		<?php 
/* tag "span" from line 4 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('mAdmin.xhtml/IncludeMETA', $_thistpl) ;
$ctx->popSlots() ;
?>

		<?php 
/* tag "span" from line 5 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('mAdmin.xhtml/IncludeCSS', $_thistpl) ;
$ctx->popSlots() ;
?>

	</head>
	<?php /* tag "body" from line 7 */; ?>
<body>
		<?php 
/* tag "div" from line 8 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('mAdmin.xhtml/Header', $_thistpl) ;
$ctx->popSlots() ;
?>

		<?php 
/* tag "div" from line 9 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('mAdmin.xhtml/UserNavigation', $_thistpl) ;
$ctx->popSlots() ;
?>
		
		<?php /* tag "div" from line 10 */; ?>
<div id="sidebar">			
		</div>			
		<?php /* tag "div" from line 12 */; ?>
<div id="content">
			<?php /* tag "div" from line 13 */; ?>
<div id="content-header">
				<?php /* tag "h1" from line 14 */; ?>
<h1><?php echo phptal_escape($ctx->Title); ?>
</h1>
				<?php /* tag "div" from line 15 */; ?>
<div class="btn-group">
					<?php /* tag "a" from line 16 */; ?>
<a href="/app/rss/ins/load" class="btn btn-success sinleins"><?php /* tag "i" from line 16 */; ?>
<i class="glyphicon glyphicon-plus"> Thêm mới</i></a>
				</div>
			</div>
			<?php 
/* tag "div" from line 19 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('mAdmin.xhtml/Breadcrumb', $_thistpl) ;
$ctx->popSlots() ;
?>

			<?php /* tag "div" from line 20 */; ?>
<div class="container-fluid">
				<?php /* tag "div" from line 21 */; ?>
<div class="row">
					<?php /* tag "div" from line 22 */; ?>
<div class="col-12">
						<?php /* tag "div" from line 23 */; ?>
<div class="widget-box">
							<?php /* tag "div" from line 24 */; ?>
<div class="widget-content nopadding">
								<?php /* tag "table" from line 25 */; ?>
<table class="table table-bordered table-striped table-hover">
									<?php /* tag "thead" from line 26 */; ?>
<thead>
										<?php /* tag "tr" from line 27 */; ?>
<tr>
											<?php /* tag "th" from line 28 */; ?>
<th width="40"><?php /* tag "input" from line 28 */; ?>
<input type="checkbox" id="title-table-checkbox" name="title-table-checkbox"/></th>
											<?php /* tag "th" from line 29 */; ?>
<th width="32">STT</th>
											<?php /* tag "th" from line 30 */; ?>
<th><?php /* tag "div" from line 30 */; ?>
<div class="text-left">Web Gốc</div></th>
											<?php /* tag "th" from line 31 */; ?>
<th><?php /* tag "div" from line 31 */; ?>
<div class="text-left">Địa chỉ Web</div></th>
											<?php /* tag "th" from line 32 */; ?>
<th><?php /* tag "div" from line 32 */; ?>
<div class="text-left">Địa chỉ Rss lấy tin</div></th>
											<?php /* tag "th" from line 33 */; ?>
<th><?php /* tag "div" from line 33 */; ?>
<div class="text-left">Thể Loại</div></th>
											<?php /* tag "th" from line 34 */; ?>
<th><?php /* tag "div" from line 34 */; ?>
<div class="text-left">Khả dụng</div></th>
											<?php /* tag "th" from line 35 */; ?>
<th width="32"></th>
										</tr>
									</thead>
									<?php /* tag "tbody" from line 38 */; ?>
<tbody>
										<?php 
/* tag "tr" from line 39 */ ;
$_tmp_1 = $ctx->repeat ;
$_tmp_1->Rss = new PHPTAL_RepeatController($ctx->RssAll)
 ;
$ctx = $tpl->pushContext() ;
foreach ($_tmp_1->Rss as $ctx->Rss): ;
?>
<tr class="content-rows">
											<?php /* tag "td" from line 40 */; ?>
<td class="center"><?php 
/* tag "input" from line 40 */ ;
if (null !== ($_tmp_2 = ($ctx->path($ctx->Customer, 'getId')))):  ;
$_tmp_2 = ' data-id="'.phptal_escape($_tmp_2).'"' ;
else:  ;
$_tmp_2 = '' ;
endif ;
?>
<input class="CheckedDel" type="checkbox"<?php echo $_tmp_2 ?>
/></td>
											<?php /* tag "td" from line 41 */; ?>
<td width="32" align="center"><?php /* tag "div" from line 41 */; ?>
<div><?php echo phptal_escape($ctx->path($ctx->repeat, 'Rss/number')); ?>
</div></td>											
											<?php /* tag "td" from line 42 */; ?>
<td align="left">
												<?php 
/* tag "a" from line 43 */ ;
if (null !== ($_tmp_2 = ($ctx->path($ctx->Rss, 'getURLUpdLoad')))):  ;
$_tmp_2 = ' href="'.phptal_escape($_tmp_2).'"' ;
else:  ;
$_tmp_2 = '' ;
endif ;
?>
<a<?php echo $_tmp_2 ?>
><?php echo phptal_escape($ctx->path($ctx->Rss, 'getName')); ?>
</a>
											</td>
											<?php /* tag "td" from line 45 */; ?>
<td align="left"><?php /* tag "div" from line 45 */; ?>
<div><?php echo phptal_escape($ctx->path($ctx->Rss, 'getWeburl')); ?>
</div></td>
											<?php /* tag "td" from line 46 */; ?>
<td align="left"><?php /* tag "div" from line 46 */; ?>
<div><?php echo phptal_escape($ctx->path($ctx->Rss, 'getRssurl')); ?>
</div></td>
											<?php /* tag "td" from line 47 */; ?>
<td align="left"><?php /* tag "div" from line 47 */; ?>
<div><?php echo phptal_escape($ctx->path($ctx->Rss, 'getType')); ?>
</div></td>
											<?php /* tag "td" from line 48 */; ?>
<td align="left"><?php /* tag "div" from line 48 */; ?>
<div><?php echo phptal_escape($ctx->path($ctx->Rss, 'getEnable')); ?>
</div></td>
											<?php /* tag "td" from line 49 */; ?>
<td width="32" class="center"><?php 
/* tag "a" from line 49 */ ;
if (null !== ($_tmp_2 = ($ctx->path($ctx->Rss, 'getId')))):  ;
$_tmp_2 = ' data-id="'.phptal_escape($_tmp_2).'"' ;
else:  ;
$_tmp_2 = '' ;
endif ;
?>
<a class="remove-item" href="#DialogDel" data-toggle="modal"<?php echo $_tmp_2 ?>
><?php /* tag "i" from line 49 */; ?>
<i class="glyphicon glyphicon-remove"></i></a></td>
										</tr><?php 
endforeach ;
$ctx = $tpl->popContext() ;
?>

									</tbody>
								</table>								
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
								
		<?php 
/* tag "div" from line 60 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('mAdmin.xhtml/Footer', $_thistpl) ;
$ctx->popSlots() ;
?>

		<?php 
/* tag "div" from line 61 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('mDialog.xhtml/DialogDel', $_thistpl) ;
$ctx->popSlots() ;
?>

		<?php 
/* tag "div" from line 62 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('mAdmin.xhtml/SignoutDialog', $_thistpl) ;
$ctx->popSlots() ;
?>

		<?php 
/* tag "span" from line 63 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('mAdmin.xhtml/IncludeJS', $_thistpl) ;
$ctx->popSlots() ;
?>

		<?php /* tag "script" from line 64 */; ?>
<script type="text/javascript">
		/*<![CDATA[*/
			//-----------------------------------------------------------------------------------
			//Delete 1 CategoryVideo			
			//-----------------------------------------------------------------------------------
		
			
			$('.remove-item').click(function(){
				$('#URLDelButton').attr('alt', $(this).attr('data-id'));
			});
			//Khi người dùng Click vào nút URLDelButton thì tiến  hành gọi Ajax xóa tự động
			$('#URLDelButton').click(function(){			
				var URL = "/object/del/RssLink/" + $(this).attr('alt');
				$.ajax({
					type: "POST",
					url: URL,
					success: function(msg){
						location.reload();
					}
				});
			});
									
						
		/*]]>*/
		</script>
	</body>
</html><?php 
/* end */ ;

}

?>
<?php /* 
*** DO NOT EDIT THIS FILE ***

Generated by PHPTAL from D:\AppWebServer\SPN_VPS\spnvps\admin.chualongvien.com\mvc\templates\AppRss.html (edit that file instead) */; ?>