<?php 
function tpl_54462aec_AppConfig__lnfdgd0Adhw3RQR2ogBmFQ(PHPTAL $tpl, PHPTAL_Context $ctx) {
$_thistpl = $tpl ;
$_translator = $tpl->getTranslator() ;
/* tag "documentElement" from line 1 */ ;
$ctx->setDocType('<!DOCTYPE html>',false) ;
?>

<?php /* tag "html" from line 2 */; ?>
<html lang="en">
	<?php /* tag "head" from line 3 */; ?>
<head>
		<?php 
/* tag "span" from line 4 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('mAdmin.xhtml/IncludeMETA', $_thistpl) ;
$ctx->popSlots() ;
?>

		<?php 
/* tag "span" from line 5 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('mAdmin.xhtml/IncludeCSS', $_thistpl) ;
$ctx->popSlots() ;
?>

	</head>
	<?php /* tag "body" from line 7 */; ?>
<body>
		<?php 
/* tag "div" from line 8 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('mAdmin.xhtml/Header', $_thistpl) ;
$ctx->popSlots() ;
?>

		<?php 
/* tag "div" from line 9 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('mAdmin.xhtml/UserNavigation', $_thistpl) ;
$ctx->popSlots() ;
?>

		<?php 
/* tag "div" from line 10 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('mAdmin.xhtml/Sidebar', $_thistpl) ;
$ctx->popSlots() ;
?>

		
		<?php /* tag "div" from line 12 */; ?>
<div id="content">
			<?php /* tag "div" from line 13 */; ?>
<div id="content-header">
				<?php /* tag "h1" from line 14 */; ?>
<h1><?php echo phptal_escape($ctx->Title); ?>
</h1>
				<?php /* tag "div" from line 15 */; ?>
<div class="btn-group">
					<?php /* tag "button" from line 16 */; ?>
<button id="insertObject" href="#DialogIns" data-toggle="modal" class="btn btn-success sinleins"><?php /* tag "i" from line 16 */; ?>
<i class="glyphicon glyphicon-plus"> Thêm mới</i></button>
				</div>
			</div>
			<?php 
/* tag "div" from line 19 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('mAdmin.xhtml/Breadcrumb', $_thistpl) ;
$ctx->popSlots() ;
?>

			<?php /* tag "div" from line 20 */; ?>
<div class="container-fluid">
				<?php /* tag "div" from line 21 */; ?>
<div class="row">
					<?php /* tag "div" from line 22 */; ?>
<div class="col-12">
						<?php /* tag "div" from line 23 */; ?>
<div class="widget-box">
							<?php /* tag "div" from line 24 */; ?>
<div class="widget-content nopadding">
								<?php /* tag "table" from line 25 */; ?>
<table class="table table-bordered table-striped table-hover">
									<?php /* tag "thead" from line 26 */; ?>
<thead>
										<?php /* tag "tr" from line 27 */; ?>
<tr>
											<?php /* tag "th" from line 28 */; ?>
<th width="30px">STT</th>
											<?php /* tag "th" from line 29 */; ?>
<th><?php /* tag "div" from line 29 */; ?>
<div class="text-left">THAM SỐ</div></th>
											<?php /* tag "th" from line 30 */; ?>
<th><?php /* tag "div" from line 30 */; ?>
<div class="text-left">GIÁ TRỊ</div></th>
											<?php /* tag "th" from line 31 */; ?>
<th width="30px"></th>
										</tr>
									</thead>
									<?php /* tag "tbody" from line 34 */; ?>
<tbody>
										<?php 
/* tag "tr" from line 35 */ ;
$_tmp_1 = $ctx->repeat ;
$_tmp_1->Config = new PHPTAL_RepeatController($ctx->ConfigAll1)
 ;
$ctx = $tpl->pushContext() ;
foreach ($_tmp_1->Config as $ctx->Config): ;
?>
<tr>
											<?php /* tag "td" from line 36 */; ?>
<td>
												<?php /* tag "div" from line 37 */; ?>
<div><?php echo phptal_escape($ctx->path($ctx->repeat, 'Config/number')); ?>
</div>
											</td>
											<?php /* tag "td" from line 39 */; ?>
<td><?php 
/* tag "a" from line 39 */ ;
if (null !== ($_tmp_2 = ($ctx->path($ctx->Config, 'getId')))):  ;
$_tmp_2 = ' data-id="'.phptal_escape($_tmp_2).'"' ;
else:  ;
$_tmp_2 = '' ;
endif ;
?>
<a class="update-item" href="#DialogEdit" data-toggle="modal" data-name="Config"<?php echo $_tmp_2 ?>
><?php echo phptal_escape($ctx->path($ctx->Config, 'getParam')); ?>
</a></td>
											<?php /* tag "td" from line 40 */; ?>
<td><?php echo phptal_escape($ctx->path($ctx->Config, 'getValue')); ?>
</td>										
											<?php /* tag "td" from line 41 */; ?>
<td class="center"><?php 
/* tag "a" from line 41 */ ;
if (null !== ($_tmp_2 = ($ctx->path($ctx->Config, 'getId')))):  ;
$_tmp_2 = ' data-id="'.phptal_escape($_tmp_2).'"' ;
else:  ;
$_tmp_2 = '' ;
endif ;
?>
<a class="remove-item" href="#deleteDialog" data-toggle="modal"<?php echo $_tmp_2 ?>
><?php /* tag "i" from line 41 */; ?>
<i class="glyphicon glyphicon-remove"></i></a></td>
										</tr><?php 
endforeach ;
$ctx = $tpl->popContext() ;
?>

									</tbody>
								</table>
								<?php /* tag "center" from line 45 */; ?>
<center>
									<?php /* tag "ul" from line 46 */; ?>
<ul class="pagination">
										<?php 
/* tag "li" from line 47 */ ;
$_tmp_2 = $ctx->repeat ;
$_tmp_2->P = new PHPTAL_RepeatController($ctx->path($ctx->PN, 'getPages'))
 ;
$ctx = $tpl->pushContext() ;
foreach ($_tmp_2->P as $ctx->P): ;
?>
<li><?php 
/* tag "a" from line 47 */ ;
if (null !== ($_tmp_1 = ($ctx->path($ctx->P, 'getURL')))):  ;
$_tmp_1 = ' href="'.phptal_escape($_tmp_1).'"' ;
else:  ;
$_tmp_1 = '' ;
endif ;
?>
<a<?php echo $_tmp_1 ?>
><?php echo phptal_escape($ctx->path($ctx->P, 'getName')); ?>
</a></li><?php 
endforeach ;
$ctx = $tpl->popContext() ;
?>

									</ul>
								</center>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		
		<!-- INSERT DIALOG  -->
		<?php /* tag "div" from line 58 */; ?>
<div id="DialogIns" class="modal fade">
			<?php /* tag "div" from line 59 */; ?>
<div class="modal-dialog">
				<?php /* tag "div" from line 60 */; ?>
<div class="modal-content">
					<?php /* tag "div" from line 61 */; ?>
<div class="modal-header">
						<?php /* tag "h3" from line 62 */; ?>
<h3><?php /* tag "i" from line 62 */; ?>
<i class="glyphicons-cogwheel modal-icon"></i>THÊM MỚI CẤU HÌNH</h3>
					</div>
					<?php /* tag "div" from line 64 */; ?>
<div class="form-horizontal">
						<?php /* tag "div" from line 65 */; ?>
<div class="modal-body">
							<?php /* tag "div" from line 66 */; ?>
<div class="form-group">
								<?php /* tag "label" from line 67 */; ?>
<label class="control-label">Tham số</label>
								<?php /* tag "div" from line 68 */; ?>
<div class="controls">
									<?php /* tag "input" from line 69 */; ?>
<input id="Param1" name="Param1" type="text" class="form-control input-small"/>
								</div>
							</div>
							<?php /* tag "div" from line 72 */; ?>
<div class="form-group">
								<?php /* tag "label" from line 73 */; ?>
<label class="control-label">Giá trị</label>
								<?php /* tag "div" from line 74 */; ?>
<div class="controls">
									<?php /* tag "input" from line 75 */; ?>
<input id="Value1" name="Value1" type="text" class="form-control input-small"/>
								</div>
							</div>
						</div>
						<?php /* tag "div" from line 79 */; ?>
<div class="modal-footer">
							<?php /* tag "button" from line 80 */; ?>
<button id="URLInsButton" class="btn btn-primary btn-small" type="submit"><?php /* tag "i" from line 80 */; ?>
<i class="glyphicons-download_alt"></i> Lưu</button>
							<?php /* tag "button" from line 81 */; ?>
<button data-dismiss="modal" class="btn btn-default btn-small"><?php /* tag "i" from line 81 */; ?>
<i class="glyphicons-undo"></i> Hủy</button>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- END INSERT DIALOG  -->
		
		<!-- UPDATE DIALOG  -->
		<?php /* tag "div" from line 90 */; ?>
<div id="DialogEdit" class="modal fade">
			<?php /* tag "div" from line 91 */; ?>
<div class="modal-dialog">
				<?php /* tag "div" from line 92 */; ?>
<div class="modal-content">
					<?php /* tag "div" from line 93 */; ?>
<div class="modal-header">
						<?php /* tag "h3" from line 94 */; ?>
<h3><?php /* tag "i" from line 94 */; ?>
<i class="glyphicons-cogwheel modal-icon"></i>CẬP NHẬT CẤU HÌNH</h3>
					</div>
					<?php /* tag "div" from line 96 */; ?>
<div class="form-horizontal">
						<?php /* tag "div" from line 97 */; ?>
<div class="modal-body">
							<?php /* tag "div" from line 98 */; ?>
<div class="form-group">
								<?php /* tag "label" from line 99 */; ?>
<label class="control-label">Tham số</label>
								<?php /* tag "div" from line 100 */; ?>
<div class="controls">
									<?php /* tag "input" from line 101 */; ?>
<input id="Param2" name="Param2" type="text" class="form-control input-small"/>
								</div>
							</div>
							<?php /* tag "div" from line 104 */; ?>
<div class="form-group">
								<?php /* tag "label" from line 105 */; ?>
<label class="control-label">Giá trị</label>
								<?php /* tag "div" from line 106 */; ?>
<div class="controls">
									<?php /* tag "input" from line 107 */; ?>
<input id="Value2" name="Value2" type="text" class="form-control input-small"/>
								</div>
							</div>
						</div>									
						<?php /* tag "div" from line 111 */; ?>
<div class="modal-footer">
							<?php /* tag "button" from line 112 */; ?>
<button id="URLUpdButton" class="btn btn-primary btn-small" type="submit"><?php /* tag "i" from line 112 */; ?>
<i class="glyphicons-download_alt"></i> Lưu</button>
							<?php /* tag "button" from line 113 */; ?>
<button data-dismiss="modal" class="btn btn-default btn-small"><?php /* tag "i" from line 113 */; ?>
<i class="glyphicons-undo"></i> Hủy</button>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- END UPDATE DIALOG  -->
		
		<?php 
/* tag "div" from line 121 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('mAdmin.xhtml/Footer', $_thistpl) ;
$ctx->popSlots() ;
?>

		<?php 
/* tag "div" from line 122 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('mDialog.xhtml/DialogDel', $_thistpl) ;
$ctx->popSlots() ;
?>

		<?php 
/* tag "div" from line 123 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('mAdmin.xhtml/SignoutDialog', $_thistpl) ;
$ctx->popSlots() ;
?>

		<?php 
/* tag "span" from line 124 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('mAdmin.xhtml/IncludeJS', $_thistpl) ;
$ctx->popSlots() ;
?>

		<?php /* tag "script" from line 125 */; ?>
<script type="text/javascript">
		/*<![CDATA[*/
			//-----------------------------------------------------------------------------------
			//Delete 1 CONFIG			
			//-----------------------------------------------------------------------------------
			$('#URLDelSelectedButton').click(function(){
				var count = 0;
				var Data = [];
				var URL = "/object/del/Config/0";
				
				$(".CheckedDel").each(function( i, obj){
					if ( $(this).is(':checked')==true ){
						count += 1;
						Data[count] = $(this).attr('data-id');
					}
				});
				
				$.ajax({
					type: "POST",
					data: {ListId:Data},
					url: URL,
					success: function(msg){
						location.reload();
					}
				});
			});
			
			$('.remove-item').click(function(){
				$('#deleteButton').attr('alt', $(this).attr('data-id'));
			});
			//Khi người dùng Click vào nút URLDelButton thì tiến  hành gọi Ajax xóa tự động
			$('#deleteButton').click(function(){			
				var URL = "/object/del/Config/" + $(this).attr('alt');
				$.ajax({
					type: "POST",
					url: URL,
					success: function(msg){
						location.reload();
					}
				});
			});
		
			//-----------------------------------------------------------------------------------
			//Insert 1 CONFIG
			$('#URLInsButton').click(function(){
				var Data = [];
				Data[0] = 'null';
				Data[1] = $('#Param1').val();
				Data[2] = $('#Value1').val();
				
				var URL = "/object/ins/Config";
				$.ajax({
					type: "POST",
					data: {Data:Data},
					url: URL,
					success: function(msg){
						location.reload();
					}
				});
			});
			
			//-----------------------------------------------------------------------------------
			//Load 1 CONFIG
			//-----------------------------------------------------------------------------------
			$('.update-item').click(function(){
				//Load dữ liệu JSON về
				var url = "/object/load/Config/" + $(this).attr('data-id');
				
				//Load dữ liệu JSON lên FORM
				$.getJSON(url, function(data){
					$('#URLUpdButton').attr('alt', data.Id);
					$('#Param2').attr('value', data.Param);
					$('#Value2').attr('value', data.Value);
				});
			});
			
			//-----------------------------------------------------------------------------------
			//Update 1 UNIT
			//-----------------------------------------------------------------------------------
			$('#URLUpdButton').click(function(){
				var Data = [];
				Data[0] = $('#URLUpdButton').attr('alt');
				Data[1] = $('#Param2').val();
				Data[2] = $('#Value2').val();
				
				var URL = "/object/upd/Config";
				$.ajax({
					type: "POST",
					data: {Data:Data},
					url: URL,
					success: function(msg){
						location.reload();
					}
				});
			});		
		/*]]>*/</script>
	</body>
</html><?php 
/* end */ ;

}

?>
<?php /* 
*** DO NOT EDIT THIS FILE ***

Generated by PHPTAL from D:\AppWebServer\SPN_VPS\spnvps\admin.chualongvien.com\mvc\templates\AppConfig.html (edit that file instead) */; ?>