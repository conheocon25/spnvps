<?php
namespace MVC\Mapper;

require_once( "mvc/base/Mapper.php" );
class Event extends Mapper implements \MVC\Domain\EventFinder{

    function __construct() {
        parent::__construct();
				
		$tblEvent = "chualongvien_event";
		
		$selectAllStmt 		= sprintf("select * from %s ORDER BY `date` DESC", $tblEvent);
		$selectStmt 		= sprintf("select *  from %s where id=?", $tblEvent);
		$updateStmt 		= sprintf("update %s set name=?, `date`=?, picture=?, content=?, `key`=? where id=?", $tblEvent);
		$insertStmt 		= sprintf("insert into %s ( name, `date`, picture, content, `key`) values(?, ?, ?, ?, ?)", $tblEvent);
		$deleteStmt 		= sprintf("delete from %s where id=?", $tblEvent);
		$findByStmt 		= sprintf("select *  from %s where id_pagoda=?", $tblEvent);
		$findByPageStmt 	= sprintf("SELECT * FROM  %s WHERE id_pagoda=:id_pagoda LIMIT :start,:max", $tblEvent);
		$findByKeyStmt 		= sprintf("select *  from %s where `key`=?", $tblEvent);	
						
        $this->selectAllStmt 	= self::$PDO->prepare($selectAllStmt);
        $this->selectStmt 		= self::$PDO->prepare($selectStmt);
        $this->updateStmt 		= self::$PDO->prepare($updateStmt);
        $this->insertStmt 		= self::$PDO->prepare($insertStmt);
		$this->deleteStmt 		= self::$PDO->prepare($deleteStmt);
		$this->findByStmt 		= self::$PDO->prepare($findByStmt);
		$this->findByKeyStmt 	= self::$PDO->prepare($findByKeyStmt);
		$this->findByPageStmt 	= self::$PDO->prepare($findByPageStmt);
    }
	
    function getCollection( array $raw ) {return new EventCollection( $raw, $this );}
    protected function doCreateObject( array $array ) {
        $obj = new \MVC\Domain\Event( 
			$array['id'],			
			$array['name'],
			$array['date'],
			$array['picture'],
			$array['content'],
			$array['key']
		);
        return $obj;
    }

    protected function targetClass() {return "Event";}
    protected function doInsert( \MVC\Domain\Object $object ) {
        $values = array( 			
			$object->getName(),
			$object->getDate(),
			$object->getPicture(),
			$object->getContent(),
			$object->getKey()
		);
        $this->insertStmt->execute( $values );
        $id = self::$PDO->lastInsertId();
        $object->setId( $id );
    }
    
    protected function doUpdate( \MVC\Domain\Object $object ) {
        $values = array(			
			$object->getName(),
			$object->getDate(),
			$object->getPicture(),
			$object->getContent(),
			$object->getKey(),
			$object->getId()
		);
        $this->updateStmt->execute( $values );
    }
	protected function doDelete(array $values) {return $this->deleteStmt->execute( $values );}

    function selectStmt() {return $this->selectStmt;}
    function selectAllStmt() {return $this->selectAllStmt;}	
	
	function findBy( $values ){
		$this->findByStmt->execute($values);
        return new EventCollection( $this->findByStmt->fetchAll(), $this);
    }
	
	function findByPage( $values ) {				
		$this->findByPageStmt->bindValue(':id_pagoda', $values[0], \PDO::PARAM_INT);
		$this->findByPageStmt->bindValue(':start', ((int)($values[1])-1)*(int)($values[2]), \PDO::PARAM_INT);
		$this->findByPageStmt->bindValue(':max', (int)($values[2]), \PDO::PARAM_INT);
		$this->findByPageStmt->execute();
        return new EventCollection( $this->findByPageStmt->fetchAll(), $this );
    }
	
	function findByKey( $values ) {	
		$this->findByKeyStmt->execute( array($values) );
        $array = $this->findByKeyStmt->fetch();
        $this->findByKeyStmt->closeCursor();
        if ( ! is_array( $array ) ) { return null; }
        if ( ! isset( $array['id'] ) ) { return null; }
        $object = $this->doCreateObject( $array );
        return $object;		
    }
}
?>